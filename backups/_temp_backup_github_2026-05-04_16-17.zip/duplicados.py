"""Lista juegos duplicados en el indice"""
import json
import os
from collections import defaultdict

ARCHIVO_DATOS = "indice_datos_grupo.json"

def normalizar(nombre):
    """Normaliza nombre para comparacion (quita simbolos, espacios, mayusculas)"""
    import re
    n = nombre.upper()
    n = re.sub(r'[^A-Z0-9]', '', n)  # solo letras y numeros
    return n

def main():
    if not os.path.exists(ARCHIVO_DATOS):
        print("No se encontro indice_datos_grupo.json")
        return
    
    with open(ARCHIVO_DATOS, "r", encoding="utf-8") as f:
        datos = json.load(f)
    
    juegos = datos["juegos"]
    print(f"Total juegos: {len(juegos)}\n")
    
    # Agrupar por nombre normalizado
    agrupado = defaultdict(list)
    for j in juegos:
        clave = normalizar(j["nombre"])
        agrupado[clave].append(j)
    
    # Filtrar solo los duplicados
    duplicados = {k: v for k, v in agrupado.items() if len(v) > 1}
    
    if not duplicados:
        print("No hay juegos duplicados.")
        input("\nPulsa Enter para cerrar...")
        return
    
    print(f"=== JUEGOS DUPLICADOS: {len(duplicados)} ===\n")
    
    # Generar reporte tambien en archivo
    lineas = [f"=== JUEGOS DUPLICADOS: {len(duplicados)} ===\n"]
    
    for clave, lista in sorted(duplicados.items(), key=lambda x: -len(x[1])):
        # Mostrar nombre y cuantas veces aparece
        nombre = lista[0]["nombre"]
        cantidad = len(lista)
        linea = f"\n[{cantidad}x] {nombre}"
        print(linea)
        lineas.append(linea)
        
        for j in lista:
            sub = f"  -> ID {j['id']}: {j['nombre']}"
            if j.get("url"):
                sub += f"\n     {j['url']}"
            print(sub)
            lineas.append(sub)
    
    # Guardar reporte
    with open("duplicados.txt", "w", encoding="utf-8") as f:
        f.write("\n".join(lineas))
    
    print(f"\n\nTotal duplicados: {sum(len(v) for v in duplicados.values())} entradas en {len(duplicados)} grupos")
    print(f"Reporte guardado en: duplicados.txt")
    input("\nPulsa Enter para cerrar...")

if __name__ == "__main__":
    main()
