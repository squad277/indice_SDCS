"""Estadisticas del indice (corregido)"""
import json

with open("indice_datos_grupo.json", "r", encoding="utf-8") as f:
    datos = json.load(f)

juegos = datos["juegos"]
total = len(juegos)

con_imagen_local = sum(1 for j in juegos if j.get("imagen_local"))
con_app_id = sum(1 for j in juegos if j.get("app_id"))

# Imagen real cargada en la web:
# 1. Si tiene imagen_local -> de Telegram (GitHub)
# 2. Si no, pero tiene app_id -> de Steam
# 3. Si no -> placeholder

con_telegram = sum(1 for j in juegos if j.get("imagen_local"))
con_steam = sum(1 for j in juegos if not j.get("imagen_local") and j.get("app_id"))
sin_imagen = total - con_telegram - con_steam

print("=" * 50)
print("ESTADISTICAS DEL INDICE")
print("=" * 50)
print(f"\nTotal juegos: {total}")
print(f"\nFuente de imagenes:")
print(f"  - Imagenes desde Steam:    {con_steam}")
print(f"  - Imagenes desde Telegram: {con_telegram} (subidas a GitHub)")
print(f"  - Sin imagen (placeholder): {sin_imagen}")
print(f"\nCobertura de caratulas: {(con_steam + con_telegram) * 100 / total:.1f}%")
print()
input("Pulsa Enter para cerrar...")
