"""
INDICE WEB SDCS v3 - by Claude para Squad_277
Mejoras incluidas:
- Fecha de subida en cada card
- Deteccion mejorada de app_id desde cualquier URL
- Cuando la primera linea es solo URL, extrae nombre del slug de Steam o de hashtags
- Descarga caratulas de Telegram para juegos sin imagen
- Limpieza automatica de nombres con __ o caracteres extra
"""

import re
import os
import io
import json
import asyncio
import requests
from datetime import datetime
from telethon import TelegramClient
from github import Github

# ============================================================
# CONFIGURACION
# ============================================================
API_ID   = 28462268
API_HASH = "243bb8e2ed0ca5ef8101f83cb5cb28ed"
PHONE    = "+34615129336"

CHAT_ID = -1001634508656

GITHUB_USER = "squad277"
GITHUB_REPO = "indice_SDCS"
GITHUB_TOKEN = ""

ARCHIVO_DATOS = "indice_datos_grupo.json"
ARCHIVO_GITHUB_TOKEN = "github_token.txt"
ARCHIVO_LOGO = "logo_sdcs.jpg"
ARCHIVO_BLACKLIST = "ids_ignorados.json"
ARCHIVO_CORRECCIONES = "correcciones_manuales.json"
ARCHIVO_BACKUP = "indice_datos_grupo.backup.json"

HEADERS_STEAM = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
}

# ============================================================
# UTILIDADES BASE
# ============================================================
def cargar_datos():
    if os.path.exists(ARCHIVO_DATOS):
        with open(ARCHIVO_DATOS, "r", encoding="utf-8") as f:
            return json.load(f)
    return {"juegos": [], "ultimo_id": 0, "chat_id": None}

def guardar_datos(datos):
    with open(ARCHIVO_DATOS, "w", encoding="utf-8") as f:
        json.dump(datos, f, ensure_ascii=False, indent=2)

def cargar_github_token():
    global GITHUB_TOKEN
    if os.path.exists(ARCHIVO_GITHUB_TOKEN):
        with open(ARCHIVO_GITHUB_TOKEN, "r") as f:
            t = f.read().strip()
            if t:
                GITHUB_TOKEN = t
                return True
    return False

def pedir_github_token():
    print("\n=== Configuracion inicial GitHub ===")
    token = input("Pega tu token (ghp_...): ").strip()
    with open(ARCHIVO_GITHUB_TOKEN, "w") as f:
        f.write(token)
    global GITHUB_TOKEN
    GITHUB_TOKEN = token
    print("Token guardado.\n")

# ============================================================
# CORRECCIONES MANUALES
# ============================================================
CORRECCIONES = {"ids_sin_steam": [], "nombres_personalizados": {}, "app_ids_personalizados": {}}

def cargar_correcciones():
    global CORRECCIONES
    if os.path.exists(ARCHIVO_CORRECCIONES):
        with open(ARCHIVO_CORRECCIONES, "r", encoding="utf-8") as f:
            CORRECCIONES = json.load(f)
    return CORRECCIONES

def aplicar_correcciones(juego):
    """Aplica correcciones manuales a un juego"""
    msg_id = str(juego["id"])
    
    # Forzar quitar app_id de Steam
    if juego["id"] in CORRECCIONES.get("ids_sin_steam", []):
        if juego.get("app_id"):
            juego["app_id"] = None
            juego["url_steam"] = None
    
    # Nombre personalizado
    if msg_id in CORRECCIONES.get("nombres_personalizados", {}):
        juego["nombre"] = CORRECCIONES["nombres_personalizados"][msg_id]
    
    # App ID personalizado
    if msg_id in CORRECCIONES.get("app_ids_personalizados", {}):
        juego["app_id"] = CORRECCIONES["app_ids_personalizados"][msg_id]
        juego["url_steam"] = f"https://store.steampowered.com/app/{juego['app_id']}"
    
    return juego

# ============================================================
# BACKUPS
# ============================================================
def crear_backup_local():
    """Copia el JSON actual a un archivo backup"""
    if os.path.exists(ARCHIVO_DATOS):
        import shutil
        shutil.copy2(ARCHIVO_DATOS, ARCHIVO_BACKUP)
        print(f"Backup local creado: {ARCHIVO_BACKUP}")

def subir_backup_github(repo, datos):
    """Sube backup del JSON a GitHub para tenerlo respaldado online"""
    try:
        contenido = json.dumps(datos, ensure_ascii=False, indent=2)
        ruta = f"backups/indice_datos_grupo.json"
        try:
            archivo = repo.get_contents(ruta)
            repo.update_file(ruta, f"Backup {datetime.now().strftime('%Y-%m-%d %H:%M')}", contenido, archivo.sha)
        except:
            repo.create_file(ruta, "Crear backup inicial", contenido)
        print("Backup en GitHub actualizado")
        return True
    except Exception as e:
        print(f"Error subiendo backup a GitHub: {e}")
        return False

# ============================================================
# BLACKLIST
# ============================================================
BLACKLIST_IDS = set()

def cargar_blacklist():
    global BLACKLIST_IDS
    if os.path.exists(ARCHIVO_BLACKLIST):
        with open(ARCHIVO_BLACKLIST, "r", encoding="utf-8") as f:
            BLACKLIST_IDS = set(json.load(f))
    return BLACKLIST_IDS

# ============================================================
# EXTRAER DATOS DEL MENSAJE (mejorado)
# ============================================================
REGEX_URL = re.compile(r'https?://\S+')
REGEX_STEAM_APP = re.compile(r'store\.steampowered\.com/app/(\d+)(?:/([^/\s]+))?', re.IGNORECASE)

def es_solo_url(linea):
    """Devuelve True si la linea es solo una URL"""
    s = linea.strip()
    if not s:
        return False
    return bool(re.fullmatch(r'https?://\S+', s))

def slug_a_nombre(slug):
    """Convierte 'Spelunky_2' -> 'Spelunky 2', 'fall_of_an_empire' -> 'Fall Of An Empire'"""
    if not slug:
        return None
    nombre = slug.replace('_', ' ').replace('-', ' ')
    nombre = re.sub(r'\s+', ' ', nombre).strip()
    return nombre.title()

def nombres_coherentes(nombre_juego, slug_steam):
    """Comprueba si el nombre del juego y el slug de Steam coinciden razonablemente.
    Devuelve True si parecen el mismo juego, False si son MUY diferentes."""
    if not nombre_juego or not slug_steam:
        return True  # No hay con que comparar, asumir OK
    
    # Normalizar ambos: quitar simbolos, guiones, todo a minusculas
    def normalizar(s):
        s = s.lower()
        s = re.sub(r'[^a-z0-9]', '', s)
        return s
    
    n1 = normalizar(nombre_juego)
    n2 = normalizar(slug_steam)
    
    if not n1 or not n2:
        return True
    
    # Quitar terminos como remastered, edition, dlc, etc del nombre del juego
    palabras_descarte = ['remastered', 'edition', 'definitive', 'goty', 'gotyedition',
                          'completeedition', 'directorscut', 'remake', 'enhanced',
                          'specialedition', 'ultimateedition', 'deluxeedition',
                          'premiumedition', 'collectorsedition', 'goldedition',
                          'platinumedition']
    for p in palabras_descarte:
        n1 = n1.replace(p, '')
        n2 = n2.replace(p, '')
    
    if not n1 or not n2:
        return True
    
    # Comprobar si una contiene la otra (al menos un 50%)
    corta, larga = (n1, n2) if len(n1) <= len(n2) else (n2, n1)
    
    # Si la corta tiene menos de 4 chars, ser permisivo
    if len(corta) < 4:
        return True
    
    # Si la corta esta contenida en la larga, son coherentes
    if corta in larga:
        return True
    
    # Comprobar primeros caracteres (al menos 4 iguales)
    primeros = min(4, len(corta))
    if n1[:primeros] == n2[:primeros]:
        return True
    
    # Distintas
    return False

def extraer_nombre_de_hashtags(texto):
    """Extrae nombre de hashtags tipo #Spelunky_2 #Portable"""
    matches = re.findall(r'#([A-Za-z][A-Za-z0-9_]+)', texto)
    palabras_excluir = {
        'portable', 'metroidvania', 'accion', 'action', 'rpg', 'aventura',
        'aventuras', 'puzzle', 'simulator', 'simulacion', 'estrategia',
        'strategy', 'horror', 'survival', 'plataformas', 'platformer',
        'racing', 'carreras', 'shooter', 'fps', 'lucha', 'fighting',
        'casual', 'indie', 'multiplayer', 'singleplayer', 'cooperativo',
        'coop', 'roguelike', 'roguelite', 'sandbox', 'mundo_abierto',
        'open_world', 'arcade', 'crafting', 'construccion', 'building',
        'rol', 'mmorpg', 'mmo', 'sports', 'deportes', 'musica', 'music',
        'ritmo', 'rhythm', 'card', 'cartas', 'tactico', 'tactical',
        'bullet_hell', 'metalico', 'soulslike', 'visual_novel', 'novela',
        'aventura_grafica'
    }
    candidatos = []
    for m in matches:
        if m.lower() not in palabras_excluir and len(m) >= 3:
            candidatos.append(m)
    if candidatos:
        # El primer hashtag (mas largo o el primero que parece nombre)
        candidatos.sort(key=lambda x: -len(x))
        return slug_a_nombre(candidatos[0])
    return None

def extraer_url_steam_de_texto(texto):
    """Busca URLs de Steam en el texto"""
    if not texto:
        return None
    m = REGEX_STEAM_APP.search(texto)
    if m:
        app_id = m.group(1)
        slug = m.group(2)
        return app_id, slug
    return None, None

def extraer_url_steam(msg):
    """Devuelve (url_steam, app_id, slug) buscando en entidades y texto"""
    # 1. Buscar en entidades (text_link)
    if msg.entities:
        for entity in msg.entities:
            if hasattr(entity, 'url') and entity.url and 'store.steampowered.com' in entity.url:
                m = REGEX_STEAM_APP.search(entity.url)
                if m:
                    return entity.url, m.group(1), m.group(2)
    
    # 2. Buscar URL directa en el texto
    if msg.text:
        urls = REGEX_URL.findall(msg.text)
        for url in urls:
            m = REGEX_STEAM_APP.search(url)
            if m:
                return url, m.group(1), m.group(2)
    
    return None, None, None

def extraer_nombre_juego(texto, slug_steam=None):
    """
    Extrae el nombre del juego con multiples estrategias:
    1. Si la primera linea es texto (no URL), usarla
    2. Si es URL, intentar con hashtags
    3. Si no hay hashtags utiles, usar el slug de la URL Steam
    """
    if not texto:
        return None
    
    lineas = [l for l in texto.split('\n') if l.strip()]
    if not lineas:
        return None
    
    primera_linea = lineas[0].strip()
    
    # Caso 1: la primera linea es solo URL -> NO es el nombre
    if es_solo_url(primera_linea):
        # Probar con hashtags
        nombre_hashtag = extraer_nombre_de_hashtags(texto)
        if nombre_hashtag:
            return nombre_hashtag
        # Probar con slug
        if slug_steam:
            return slug_a_nombre(slug_steam).upper()
        return None
    
    # Caso 2: primera linea contiene URL al final pero tiene texto antes
    # Quitar URLs de la primera linea
    primera_sin_url = REGEX_URL.sub('', primera_linea).strip()
    if not primera_sin_url:
        # La linea era solo URL con espacios
        nombre_hashtag = extraer_nombre_de_hashtags(texto)
        if nombre_hashtag:
            return nombre_hashtag
        if slug_steam:
            return slug_a_nombre(slug_steam).upper()
        return None
    
    # Caso 3: primera linea es texto normal
    nombre = re.sub(r'^[^\w]*', '', primera_sin_url).strip()
    if not nombre or len(nombre) < 3:
        return None
    nombre = nombre.strip("_").strip()
    if len(nombre) < 3:
        return None
    
    excluir = ['Portable', 'Link Steam', 'Proton', 'ESPAÑOL', 'Prueba', 'No encontre',
               'Tampoco', 'Pegame', 'PRUEBA', 'Escribeme', 'Total', 'Mensaje fijado']
    if any(p.lower() in nombre.lower() for p in excluir):
        return None
    if not any(c.isupper() for c in nombre):
        return None
    return nombre

def construir_url_mensaje(chat_id, msg_id):
    chat_str = str(chat_id)
    if chat_str.startswith("-100"):
        chat_short = chat_str[4:]
    else:
        chat_short = chat_str.lstrip("-")
    return f"https://t.me/c/{chat_short}/{msg_id}"

def formatear_fecha(fecha):
    """De datetime a 'DD/MM/YY'"""
    if not fecha:
        return ""
    if isinstance(fecha, str):
        try:
            fecha = datetime.fromisoformat(fecha.replace("Z", "+00:00"))
        except:
            return fecha
    return fecha.strftime("%d/%m/%y")

# ============================================================
# IMAGENES
# ============================================================
def imagen_steam_disponible(app_id):
    try:
        url = f"https://cdn.cloudflare.steamstatic.com/steam/apps/{app_id}/header.jpg"
        r = requests.head(url, headers=HEADERS_STEAM, timeout=5, allow_redirects=True)
        return r.status_code == 200
    except:
        return False

async def descargar_foto_telegram(client, msg_id):
    try:
        msg = await client.get_messages(CHAT_ID, ids=msg_id)
        if msg and msg.photo:
            buf = io.BytesIO()
            await client.download_media(msg, file=buf)
            buf.seek(0)
            return buf.read()
    except Exception as e:
        print(f"  Error descargando foto del msg {msg_id}: {e}")
    return None

# ============================================================
# GITHUB
# ============================================================
def obtener_repo():
    g = Github(GITHUB_TOKEN)
    return g.get_user().get_repo(GITHUB_REPO)

def archivo_existe_en_github(repo, path):
    try:
        repo.get_contents(path)
        return True
    except:
        return False

def subir_archivo_github(repo, path, contenido_bytes, mensaje="Subir archivo"):
    try:
        try:
            archivo = repo.get_contents(path)
            repo.update_file(path, mensaje, contenido_bytes, archivo.sha)
        except:
            repo.create_file(path, mensaje, contenido_bytes)
        return True
    except Exception as e:
        print(f"  Error subiendo {path}: {e}")
        return False

def subir_html_github(repo, html):
    mensaje = f"Actualizar indice {datetime.now().strftime('%Y-%m-%d %H:%M')}"
    try:
        archivo = repo.get_contents("index.html")
        repo.update_file("index.html", mensaje, html, archivo.sha)
    except:
        repo.create_file("index.html", "Crear indice", html)

def subir_logo_github(repo):
    if not os.path.exists(ARCHIVO_LOGO):
        return False
    if archivo_existe_en_github(repo, "logo.jpg"):
        return True
    with open(ARCHIVO_LOGO, "rb") as f:
        contenido = f.read()
    return subir_archivo_github(repo, "logo.jpg", contenido, "Subir logo SDCS")

# ============================================================
# GENERADOR HTML
# ============================================================
def generar_html(juegos, ultima_actualizacion_ids=None):
    fecha = datetime.now().strftime("%d/%m/%y · %H:%M")
    total = len(juegos)
    
    if ultima_actualizacion_ids is None:
        ultima_actualizacion_ids = set()
    
    juegos_ord = sorted(juegos, key=lambda x: x["nombre"].upper())
    grupos = {}
    for j in juegos_ord:
        letra = j["nombre"][0].upper()
        if not letra.isalpha():
            letra = "#"
        grupos.setdefault(letra, []).append(j)
    
    ultimas_subidas = [j for j in juegos if j["id"] in ultima_actualizacion_ids]
    ultimas_subidas = sorted(ultimas_subidas, key=lambda x: x["id"], reverse=True)[:8]
    letras_disponibles = sorted(grupos.keys())
    
    def card_html(juego, es_destacado=False):
        nombre = juego["nombre"]
        if juego.get("imagen_local"):
            img_url = f"./imagenes/{juego['id']}.jpg"
        elif juego.get("app_id"):
            img_url = f"https://cdn.cloudflare.steamstatic.com/steam/apps/{juego['app_id']}/header.jpg"
        else:
            img_url = ""
        
        if img_url:
            estilo_img = f"background-image: url('{img_url}'); background-size: cover; background-position: center;"
        else:
            estilo_img = ""
        
        badge = '<div class="badge-new">NEW</div>' if es_destacado else ''
        
        letra_orig = nombre[0].upper()
        letra_data = "NUM" if not letra_orig.isalpha() else letra_orig
        
        fecha_str = formatear_fecha(juego.get("fecha", ""))
        fecha_html = f'<div class="fecha">({fecha_str})</div>' if fecha_str else ''
        
        # Datos para el modal
        app_id = juego.get("app_id", "") or ""
        url_telegram = juego["url"]
        nombre_escapado = nombre.replace('"', '&quot;')
        
        return f'''
        <div class="card" data-letra="{letra_data}" data-nombre="{nombre.lower()}" data-app-id="{app_id}" data-img="{img_url}" data-nombre-titulo="{nombre_escapado}" data-url-telegram="{url_telegram}" onclick="abrirModal(this)">
            <div class="cover" style="{estilo_img}">
                <div class="fb-text">{nombre}</div>
                {badge}
            </div>
            <div class="info">
                <div class="nombre">{nombre}</div>
                {fecha_html}
            </div>
        </div>'''
    
    destacados_html = "\n".join([card_html(j, True) for j in ultimas_subidas])
    
    secciones = []
    for letra in letras_disponibles:
        juegos_letra = grupos[letra]
        cards = "\n".join([card_html(j) for j in juegos_letra])
        letra_data = "NUM" if letra == "#" else letra
        secciones.append(f'''
        <div class="seccion-letra" data-letra="{letra_data}">
            <div class="titulo-seccion">LETRA {letra} · {len(juegos_letra)} JUEGOS</div>
            <div class="grid">
                {cards}
            </div>
        </div>''')
    secciones_html = "\n".join(secciones)
    
    botones_letra = ['<span class="btn-letra activo" data-letra="todos">Todos</span>']
    for l in letras_disponibles:
        letra_data = "NUM" if l == "#" else l
        botones_letra.append(f'<span class="btn-letra" data-letra="{letra_data}">{l}</span>')
    botones_html = "\n".join(botones_letra)
    
    html = f'''<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SDCS - Indice de Juegos</title>
<style>
* {{ margin: 0; padding: 0; box-sizing: border-box; }}
body {{
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    background: #0d1117;
    color: white;
    min-height: 100vh;
}}
.header {{
    background: linear-gradient(180deg, #1a1f2e 0%, #0d1117 100%);
    padding: 16px 22px;
    border-bottom: 2px solid #00d4aa;
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 12px;
}}
.logo-wrap {{ display: flex; align-items: center; gap: 14px; }}
.logo {{
    width: 48px; height: 48px;
    border-radius: 6px;
    overflow: hidden;
    background: #00d4aa;
    flex-shrink: 0;
}}
.logo img {{ width: 100%; height: 100%; object-fit: cover; display: block; }}
.titulo-main {{ font-size: 14px; color: white; font-weight: 500; }}
.stats {{ display: flex; gap: 18px; font-size: 11px; }}
.stat {{ text-align: right; }}
.stat-label {{ color: #6b7280; text-transform: uppercase; letter-spacing: 1px; }}
.stat-num {{ color: #00d4aa; font-weight: 600; font-size: 16px; }}
.toolbar {{
    padding: 14px 22px; display: flex; gap: 8px;
    background: #0d1117; border-bottom: 1px solid rgba(255,255,255,0.05);
}}
.toolbar input {{
    flex: 1; background: rgba(255,255,255,0.04);
    border: 1px solid rgba(255,255,255,0.08); color: white;
    padding: 8px 12px; border-radius: 4px; font-size: 13px;
}}
.toolbar input:focus {{ outline: 1px solid #00d4aa; }}
.filtros {{
    padding: 14px 22px; display: flex; gap: 6px; flex-wrap: wrap;
    background: #0d1117; border-bottom: 1px solid rgba(255,255,255,0.05);
}}
.btn-letra {{
    font-size: 11px; padding: 4px 10px; border-radius: 4px;
    background: rgba(255,255,255,0.04); color: #9ca3af;
    border: 1px solid rgba(255,255,255,0.08); cursor: pointer;
    user-select: none; transition: all 0.15s;
}}
.btn-letra:hover {{ color: white; }}
.btn-letra.activo {{
    background: rgba(0,212,170,0.15); color: #00d4aa;
    border-color: rgba(0,212,170,0.3); font-weight: 500;
}}
.contenido {{ padding: 18px 22px; }}
.titulo-seccion {{
    font-size: 10px; color: #6b7280; letter-spacing: 1.5px;
    text-transform: uppercase; margin-bottom: 12px;
}}
.seccion-letra {{ margin-bottom: 24px; }}
.grid {{
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(180px, 220px));
    gap: 10px; justify-content: start;
}}
.card {{
    border-radius: 6px; overflow: hidden;
    background: #161b22; border: 1px solid rgba(255,255,255,0.05);
    cursor: pointer; text-decoration: none; color: white;
    transition: all 0.15s; display: flex; flex-direction: column;
}}
.card:hover {{
    border-color: #00d4aa; transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,212,170,0.2);
}}
.card .cover {{
    aspect-ratio: 16/9; background-color: #1a3a5c;
    position: relative; overflow: hidden;
}}
.card .cover .fb-text {{
    display: none; position: absolute; inset: 0;
    padding: 12px; align-items: center; justify-content: center;
    text-align: center; font-size: 13px; font-weight: 600; color: white;
    background: linear-gradient(135deg, #1a3a5c 0%, #2c5f8d 100%);
    text-shadow: 0 1px 4px rgba(0,0,0,0.6);
}}
.card .cover[style=""] .fb-text {{ display: flex; }}
.badge-new {{
    position: absolute; top: 6px; right: 6px;
    background: rgba(0,0,0,0.7); padding: 2px 6px;
    border-radius: 3px; font-size: 9px; color: #00d4aa;
    font-weight: 500; letter-spacing: 0.5px;
}}
.card .info {{ padding: 6px 8px; }}
.card .nombre {{
    font-size: 11px; font-weight: 500; color: white;
    white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
}}
.card .fecha {{
    font-size: 9px; font-weight: 400; color: #00d4aa;
    margin-top: 2px;
}}
.footer {{
    background: #0a0d12; padding: 10px 22px;
    border-top: 1px solid rgba(255,255,255,0.05);
    display: flex; justify-content: space-between;
    font-size: 10px; color: #6b7280; letter-spacing: 0.5px;
}}
.oculto {{ display: none !important; }}
.btn-arriba {{
    position: fixed; bottom: 20px; right: 20px;
    width: 44px; height: 44px;
    background: #00d4aa; color: #0d1117;
    border: none; border-radius: 50%;
    font-size: 20px; font-weight: bold;
    cursor: pointer; box-shadow: 0 4px 12px rgba(0,212,170,0.4);
    opacity: 0; visibility: hidden; transition: all 0.25s;
    display: flex; align-items: center; justify-content: center; z-index: 100;
}}
.btn-arriba.visible {{ opacity: 1; visibility: visible; }}
.btn-arriba:hover {{ background: #00f0c0; transform: translateY(-2px); }}
@media (max-width: 600px) {{
    .grid {{ grid-template-columns: repeat(auto-fill, minmax(140px, 1fr)); }}
    .stats {{ font-size: 10px; }}
}}

/* === MODAL === */
.modal-overlay {{
    position: fixed; inset: 0;
    background: rgba(0,0,0,0.85);
    display: none;
    align-items: center; justify-content: center;
    z-index: 1000;
    padding: 20px;
    overflow-y: auto;
}}
.modal-overlay.activo {{ display: flex; }}
.modal {{
    background: #161b22;
    border-radius: 8px;
    max-width: 720px; width: 100%;
    overflow: hidden;
    border: 1px solid rgba(255,255,255,0.1);
    position: relative;
    max-height: 95vh;
    display: flex; flex-direction: column;
}}
.modal-cerrar {{
    position: absolute; top: 12px; right: 12px;
    width: 32px; height: 32px;
    background: rgba(0,0,0,0.7); color: white;
    border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    cursor: pointer; z-index: 10; font-size: 18px;
    border: none;
}}
.modal-imagen {{
    aspect-ratio: 16/9;
    background: linear-gradient(135deg, #1a3a5c 0%, #2c5f8d 100%);
    background-size: cover; background-position: center;
    position: relative;
    flex-shrink: 0;
}}
.modal-imagen-titulo {{
    position: absolute; inset: 0;
    display: flex; align-items: center; justify-content: center;
    color: white; font-size: 22px; font-weight: 600;
    text-shadow: 0 2px 8px rgba(0,0,0,0.6);
    text-align: center; padding: 20px;
}}
.modal-flecha {{
    position: absolute; top: 50%; transform: translateY(-50%);
    background: rgba(0,0,0,0.6); color: white;
    width: 36px; height: 36px;
    border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    cursor: pointer; font-size: 20px;
    border: none;
    transition: background 0.15s;
}}
.modal-flecha:hover {{ background: rgba(0,0,0,0.8); }}
.modal-flecha-izq {{ left: 12px; }}
.modal-flecha-der {{ right: 12px; }}
.modal-thumbnails {{
    display: grid; grid-template-columns: repeat(4, 1fr);
    gap: 4px; padding: 4px; background: #0d1117;
    flex-shrink: 0;
}}
.modal-thumb {{
    aspect-ratio: 16/9;
    background-size: cover; background-position: center;
    border-radius: 4px; cursor: pointer;
    opacity: 0.6; transition: opacity 0.15s;
    border: 2px solid transparent;
}}
.modal-thumb:hover {{ opacity: 0.9; }}
.modal-thumb.activo {{ opacity: 1; border-color: #00d4aa; }}
.modal-info {{
    padding: 18px 20px;
    overflow-y: auto;
    flex: 1;
}}
.modal-titulo-fila {{
    display: flex; justify-content: space-between;
    align-items: flex-start; gap: 12px;
    margin-bottom: 8px; flex-wrap: wrap;
}}
.modal-titulo {{ font-size: 20px; font-weight: 600; margin: 0; color: white; }}
.modal-subtitulo {{ font-size: 11px; color: #6b7280; margin-top: 4px; }}
.modal-tags {{
    display: flex; gap: 4px; flex-wrap: wrap;
    margin: 10px 0 12px;
}}
.modal-tag {{
    font-size: 10px; padding: 3px 8px; border-radius: 3px;
    background: rgba(255,255,255,0.06); color: #9ca3af;
}}
.modal-tag.principal {{
    background: rgba(0,212,170,0.15); color: #00d4aa;
    border: 1px solid rgba(0,212,170,0.3);
}}
.modal-descripcion {{
    font-size: 13px; color: #c9d1d9;
    line-height: 1.5; margin: 8px 0 14px;
}}
.modal-meta {{
    display: flex; gap: 12px; font-size: 11px;
    color: #6b7280; margin-bottom: 12px; flex-wrap: wrap;
}}
.modal-botones {{
    display: flex; gap: 8px; margin-top: 14px; flex-wrap: wrap;
}}
.modal-btn {{
    flex: 1; min-width: 200px;
    padding: 10px 16px; border-radius: 4px;
    font-size: 13px; text-align: center; cursor: pointer;
    text-decoration: none; display: block;
}}
.modal-btn-principal {{
    background: #00d4aa; color: #0d1117; font-weight: 600;
}}
.modal-btn-principal:hover {{ background: #00f0c0; }}
.modal-btn-secundario {{
    background: rgba(255,255,255,0.06); color: white;
    font-weight: 500; border: 1px solid rgba(255,255,255,0.1);
}}
.modal-btn-secundario:hover {{ background: rgba(255,255,255,0.1); }}
.modal-loading {{
    text-align: center; padding: 20px; color: #6b7280;
    font-size: 12px;
}}
.card {{ cursor: pointer; }}
</style>
</head>
<body>

<div class="header">
    <div class="logo-wrap">
        <div class="logo"><img src="./logo.jpg" alt="SDCS"></div>
        <div><div class="titulo-main">SDCS · Grupo Steam Deck</div></div>
    </div>
    <div class="stats">
        <div class="stat">
            <div class="stat-label">Coleccion</div>
            <div class="stat-num">{total:,}</div>
        </div>
    </div>
</div>

<div class="toolbar">
    <input type="text" id="buscador" placeholder="Buscar juego..." />
</div>

<div class="filtros">
    {botones_html}
</div>

<div class="contenido">
    <div class="seccion-letra" data-letra="DESTACADOS">
        <div class="titulo-seccion">ULTIMAS SUBIDAS</div>
        <div class="grid">
            {destacados_html}
        </div>
    </div>
    {secciones_html}
</div>

<div class="footer">
    <span>SDCS · {total:,} juegos</span>
    <span>Actualizado · {fecha}</span>
</div>

<button class="btn-arriba" id="btnArriba" title="Subir arriba">↑</button>

<!-- MODAL -->
<div class="modal-overlay" id="modalOverlay" onclick="if(event.target===this) cerrarModal()">
    <div class="modal">
        <button class="modal-cerrar" onclick="cerrarModal()">×</button>
        <div class="modal-imagen" id="modalImagen">
            <div class="modal-imagen-titulo" id="modalImagenTitulo"></div>
            <button class="modal-flecha modal-flecha-izq" id="modalFlechaIzq" onclick="cambiarScreenshot(-1)">‹</button>
            <button class="modal-flecha modal-flecha-der" id="modalFlechaDer" onclick="cambiarScreenshot(1)">›</button>
        </div>
        <div class="modal-thumbnails" id="modalThumbnails"></div>
        <div class="modal-info">
            <div class="modal-titulo-fila">
                <div>
                    <h2 class="modal-titulo" id="modalTitulo"></h2>
                    <div class="modal-subtitulo" id="modalSubtitulo"></div>
                </div>
            </div>
            <div class="modal-tags" id="modalTags"></div>
            <p class="modal-descripcion" id="modalDescripcion"></p>
            <div class="modal-meta" id="modalMeta"></div>
            <div class="modal-botones">
                <a class="modal-btn modal-btn-principal" id="modalBtnTelegram" target="_blank">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" style="vertical-align:-3px;margin-right:6px;"><path d="M9.78 18.65l.28-4.23 7.68-6.92c.34-.31-.07-.46-.52-.19L7.74 13.3 3.64 12c-.88-.25-.89-.86.2-1.3l15.97-6.16c.73-.33 1.43.18 1.15 1.3l-2.72 12.81c-.19.91-.74 1.13-1.5.71L12.6 16.3l-1.99 1.93c-.23.23-.42.42-.83.42z"/></svg>
                    Descargar desde Telegram
                </a>
                <a class="modal-btn modal-btn-secundario" id="modalBtnSteam" target="_blank" style="display:none">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" style="vertical-align:-3px;margin-right:6px;"><path d="M11.979 0C5.678 0 .511 4.86.022 11.037l6.432 2.658c.545-.371 1.203-.59 1.912-.59.063 0 .125.004.188.006l2.861-4.142V8.91c0-2.495 2.028-4.524 4.524-4.524 2.494 0 4.524 2.031 4.524 4.527s-2.03 4.525-4.524 4.525h-.105l-4.076 2.911c0 .052.004.105.004.159 0 1.875-1.515 3.396-3.39 3.396-1.635 0-3.016-1.173-3.331-2.727L.436 15.27C1.862 20.307 6.486 24 11.979 24c6.627 0 11.999-5.373 11.999-12S18.605 0 11.979 0zM7.54 18.21l-1.473-.61c.262.543.714.999 1.314 1.25 1.297.539 2.793-.076 3.332-1.375.263-.63.264-1.319.005-1.949s-.75-1.121-1.377-1.383c-.624-.26-1.29-.249-1.878-.03l1.523.63c.956.4 1.409 1.5 1.009 2.456-.397.957-1.497 1.41-2.454 1.012zm14.97-9.299c0 1.66-1.349 3.011-3.012 3.011-1.66 0-3.01-1.351-3.01-3.011 0-1.66 1.35-3.012 3.01-3.012 1.663 0 3.012 1.351 3.012 3.012zm-5.273-.005c0-1.247 1.014-2.26 2.265-2.26 1.249 0 2.262 1.014 2.262 2.26 0 1.25-1.013 2.263-2.262 2.263-1.251 0-2.265-1.013-2.265-2.263z"/></svg>
                    Ver en Steam
                </a>
            </div>
        </div>
    </div>
</div>

<script>
let screenshots_actuales = [];
let screenshot_index = 0;

async function abrirModal(card) {{
    const appId = card.dataset.appId;
    const nombre = card.dataset.nombreTitulo;
    const img = card.dataset.img;
    const urlTelegram = card.dataset.urlTelegram;
    
    document.getElementById('modalTitulo').textContent = nombre;
    document.getElementById('modalBtnTelegram').href = urlTelegram;
    document.getElementById('modalSubtitulo').textContent = '';
    document.getElementById('modalTags').innerHTML = '';
    document.getElementById('modalDescripcion').textContent = '';
    document.getElementById('modalMeta').innerHTML = '';
    document.getElementById('modalThumbnails').innerHTML = '';
    
    // Imagen inicial: la caratula
    const imagenEl = document.getElementById('modalImagen');
    const tituloEl = document.getElementById('modalImagenTitulo');
    if (img) {{
        imagenEl.style.backgroundImage = `url('${{img}}')`;
        tituloEl.style.display = 'none';
    }} else {{
        imagenEl.style.backgroundImage = '';
        tituloEl.textContent = nombre;
        tituloEl.style.display = 'flex';
    }}
    
    // Resetear flechas
    document.getElementById('modalFlechaIzq').style.display = 'none';
    document.getElementById('modalFlechaDer').style.display = 'none';
    document.getElementById('modalBtnSteam').style.display = 'none';
    
    document.getElementById('modalOverlay').classList.add('activo');
    document.body.style.overflow = 'hidden';
    
    // Si tiene app_id, cargar info de Steam
    if (appId) {{
        document.getElementById('modalDescripcion').innerHTML = '<div class="modal-loading">Cargando información de Steam...</div>';
        document.getElementById('modalBtnSteam').href = `https://store.steampowered.com/app/${{appId}}`;
        document.getElementById('modalBtnSteam').style.display = 'block';
        
        try {{
            const url = `https://store.steampowered.com/api/appdetails?appids=${{appId}}&l=spanish`;
            const proxyUrl = `https://corsproxy.io/?${{encodeURIComponent(url)}}`;
            const r = await fetch(proxyUrl);
            const data = await r.json();
            const juego = data[appId]?.data;
            
            if (juego) {{
                // Subtitulo
                let subtitulo = '';
                if (juego.release_date?.date) subtitulo += juego.release_date.date;
                if (juego.developers?.length) subtitulo += ' · ' + juego.developers[0];
                document.getElementById('modalSubtitulo').textContent = subtitulo;
                
                // Generos
                if (juego.genres?.length) {{
                    const tagsHtml = juego.genres.slice(0, 5).map((g, i) => {{
                        const cls = i === 0 ? 'modal-tag principal' : 'modal-tag';
                        return `<span class="${{cls}}">${{g.description}}</span>`;
                    }}).join('');
                    document.getElementById('modalTags').innerHTML = tagsHtml;
                }}
                
                // Descripcion
                const desc = juego.short_description || '';
                document.getElementById('modalDescripcion').textContent = desc;
                
                // Meta (idioma, plataforma)
                const meta = [];
                if (juego.supported_languages?.toLowerCase().includes('spanish')) meta.push('🇪🇸 Español');
                if (juego.platforms?.windows) meta.push('🦖 Windows');
                if (juego.platforms?.mac) meta.push('🍏 macOS');
                if (juego.platforms?.linux) meta.push('🐧 Linux/SteamOS');
                document.getElementById('modalMeta').innerHTML = meta.map(m => `<span>${{m}}</span>`).join('');
                
                // Screenshots
                if (juego.screenshots?.length) {{
                    screenshots_actuales = juego.screenshots.slice(0, 4);
                    screenshot_index = 0;
                    
                    // Imagen principal: primer screenshot
                    if (screenshots_actuales[0]) {{
                        imagenEl.style.backgroundImage = `url('${{screenshots_actuales[0].path_full}}')`;
                        tituloEl.style.display = 'none';
                    }}
                    
                    // Thumbnails
                    const thumbsHtml = screenshots_actuales.map((s, i) => {{
                        const cls = i === 0 ? 'modal-thumb activo' : 'modal-thumb';
                        return `<div class="${{cls}}" style="background-image: url('${{s.path_thumbnail}}')" onclick="seleccionarScreenshot(${{i}})"></div>`;
                    }}).join('');
                    document.getElementById('modalThumbnails').innerHTML = thumbsHtml;
                    
                    // Mostrar flechas si hay mas de 1
                    if (screenshots_actuales.length > 1) {{
                        document.getElementById('modalFlechaIzq').style.display = 'flex';
                        document.getElementById('modalFlechaDer').style.display = 'flex';
                    }}
                }}
            }} else {{
                document.getElementById('modalDescripcion').textContent = '';
            }}
        }} catch (e) {{
            console.error('Error cargando Steam:', e);
            document.getElementById('modalDescripcion').textContent = '';
        }}
    }}
}}

function cerrarModal() {{
    document.getElementById('modalOverlay').classList.remove('activo');
    document.body.style.overflow = '';
    screenshots_actuales = [];
    screenshot_index = 0;
}}

function seleccionarScreenshot(idx) {{
    if (!screenshots_actuales.length) return;
    screenshot_index = idx;
    const s = screenshots_actuales[idx];
    document.getElementById('modalImagen').style.backgroundImage = `url('${{s.path_full}}')`;
    document.querySelectorAll('.modal-thumb').forEach((t, i) => {{
        t.classList.toggle('activo', i === idx);
    }});
}}

function cambiarScreenshot(dir) {{
    if (!screenshots_actuales.length) return;
    let nuevo = screenshot_index + dir;
    if (nuevo < 0) nuevo = screenshots_actuales.length - 1;
    if (nuevo >= screenshots_actuales.length) nuevo = 0;
    seleccionarScreenshot(nuevo);
}}

// Cerrar con tecla Escape
document.addEventListener('keydown', (e) => {{
    if (e.key === 'Escape') cerrarModal();
    if (e.key === 'ArrowLeft' && screenshots_actuales.length) cambiarScreenshot(-1);
    if (e.key === 'ArrowRight' && screenshots_actuales.length) cambiarScreenshot(1);
}});
</script>

<script>
const btnArriba = document.getElementById('btnArriba');
window.addEventListener('scroll', () => {{
    if (window.scrollY > 400) btnArriba.classList.add('visible');
    else btnArriba.classList.remove('visible');
}});
btnArriba.addEventListener('click', () => {{
    window.scrollTo({{ top: 0, behavior: 'smooth' }});
}});
</script>

<script>
const buscador = document.getElementById('buscador');
const secciones = document.querySelectorAll('.seccion-letra');
const botones = document.querySelectorAll('.btn-letra');
let letraActiva = 'todos';

document.querySelectorAll('.card .cover').forEach(c => {{
    const bg = c.style.backgroundImage;
    if (!bg || bg === 'none' || bg === '') {{
        c.querySelector('.fb-text').style.display = 'flex';
        return;
    }}
    const url = bg.replace(/^url\\(["']?/, '').replace(/["']?\\)$/, '');
    const img = new Image();
    img.onerror = () => {{
        c.style.backgroundImage = 'none';
        c.querySelector('.fb-text').style.display = 'flex';
    }};
    img.src = url;
}});

function aplicarFiltros() {{
    const texto = buscador.value.toLowerCase().trim();
    secciones.forEach(s => {{
        const letra = s.dataset.letra;
        const cardsSeccion = s.querySelectorAll('.card');
        let visibles = 0;
        cardsSeccion.forEach(c => {{
            const nombre = c.dataset.nombre;
            const coincideTexto = !texto || nombre.includes(texto);
            const coincideLetra = (letraActiva === 'todos') || (c.dataset.letra === letraActiva) || (letra === 'DESTACADOS' && letraActiva === 'todos');
            if (coincideTexto && coincideLetra) {{
                c.classList.remove('oculto');
                visibles++;
            }} else {{
                c.classList.add('oculto');
            }}
        }});
        if (visibles === 0) s.classList.add('oculto');
        else s.classList.remove('oculto');
    }});
}}

buscador.addEventListener('input', aplicarFiltros);
botones.forEach(b => {{
    b.addEventListener('click', () => {{
        botones.forEach(x => x.classList.remove('activo'));
        b.classList.add('activo');
        letraActiva = b.dataset.letra;
        aplicarFiltros();
    }});
}});
</script>

</body>
</html>
'''
    return html

# ============================================================
# RECONSTRUIR DATOS EXISTENTES (mejora todos los juegos)
# ============================================================
async def reprocesar_juegos_existentes(client, datos):
    """Recorre los juegos ya guardados y mejora nombres/app_ids/fechas que falten"""
    print("\n[REPROCESANDO] Mejorando datos de juegos existentes...")
    print(f"Total juegos a revisar: {len(datos['juegos'])}")
    
    necesitan_reproceso = []
    for j in datos["juegos"]:
        sin_app_id = not j.get("app_id")
        sin_fecha = not j.get("fecha")
        nombre_es_url = j["nombre"].startswith(("http://", "https://"))
        if sin_app_id or sin_fecha or nombre_es_url:
            necesitan_reproceso.append(j)
    
    print(f"Juegos a reprocesar: {len(necesitan_reproceso)}")
    
    if not necesitan_reproceso:
        return 0
    
    LOTE = 100
    actualizados = 0
    ids = [j["id"] for j in necesitan_reproceso]
    
    juego_por_id = {j["id"]: j for j in datos["juegos"]}
    
    for i in range(0, len(ids), LOTE):
        chunk = ids[i:i+LOTE]
        mensajes = await client.get_messages(CHAT_ID, ids=chunk)
        
        for msg in mensajes:
            if msg is None:
                continue
            j = juego_por_id.get(msg.id)
            if not j:
                continue
            
            cambios = False
            
            # Fecha
            if not j.get("fecha") and msg.date:
                j["fecha"] = msg.date.isoformat()
                cambios = True
            
            # URL Steam y app_id (con verificacion de coherencia)
            url_steam, app_id, slug = extraer_url_steam(msg)
            
            # Si el app_id existente no coincide con el nombre, intentar reextraer
            nombre_actual = j.get("nombre", "")
            
            # Si tenemos app_id (nuevo o viejo), verificar coherencia
            if app_id and slug:
                if not nombres_coherentes(nombre_actual, slug):
                    print(f"  [INCOHERENCIA] msg {msg.id}: '{nombre_actual}' vs '{slug}' - elimino app_id")
                    j["app_id"] = None
                    j["url_steam"] = None
                    cambios = True
                elif not j.get("app_id"):
                    j["app_id"] = app_id
                    j["url_steam"] = url_steam
                    cambios = True
            
            # Si tiene app_id antiguo pero no detectamos uno nuevo, verificar
            elif j.get("app_id") and j.get("url_steam"):
                old_match = REGEX_STEAM_APP.search(j["url_steam"])
                if old_match and old_match.group(2):
                    if not nombres_coherentes(nombre_actual, old_match.group(2)):
                        print(f"  [INCOHERENCIA] msg {msg.id}: '{nombre_actual}' vs '{old_match.group(2)}' - elimino app_id")
                        j["app_id"] = None
                        j["url_steam"] = None
                        cambios = True
            
            # Nombre: siempre intentar reextraer si es URL o si el mensaje cambio
            nombre_actual = j.get("nombre", "")
            nuevo_nombre = extraer_nombre_juego(msg.text or "", slug)
            
            # Sustituir si:
            # 1. El nombre actual es una URL (mal extraido)
            # 2. El nuevo nombre es diferente y mejor (no URL ni vacio)
            if nombre_actual.startswith(("http://", "https://")):
                if nuevo_nombre and nuevo_nombre != nombre_actual:
                    j["nombre"] = nuevo_nombre
                    cambios = True
            elif nuevo_nombre and nuevo_nombre != nombre_actual and not nuevo_nombre.startswith(("http://", "https://")):
                # El mensaje en Telegram tiene un nombre actualizado distinto
                j["nombre"] = nuevo_nombre
                cambios = True
            
            if cambios:
                actualizados += 1
        
        print(f"  Reprocesados {min(i+LOTE, len(ids))}/{len(ids)}")
    
    print(f"\nJuegos mejorados: {actualizados}")
    return actualizados

# ============================================================
# PROCESAR IMAGENES
# ============================================================
async def procesar_imagenes(client, repo, datos):
    print("\nVerificando imagenes...")
    sin_imagen = []
    
    for juego in datos["juegos"]:
        if juego.get("imagen_local"):
            continue
        app_id = juego.get("app_id")
        if app_id and imagen_steam_disponible(app_id):
            continue
        sin_imagen.append(juego)
    
    if not sin_imagen:
        print("Todas las imagenes de Steam estan disponibles.")
        return 0
    
    print(f"Imagenes a descargar de Telegram: {len(sin_imagen)}")
    
    subidas = 0
    for juego in sin_imagen:
        print(f"  -> {juego['nombre']}")
        foto = await descargar_foto_telegram(client, juego["id"])
        if foto:
            ruta = f"imagenes/{juego['id']}.jpg"
            if subir_archivo_github(repo, ruta, foto, f"Imagen {juego['nombre']}"):
                juego["imagen_local"] = True
                subidas += 1
        else:
            print(f"     No se pudo descargar foto del mensaje")
    
    return subidas

# ============================================================
# MODOS
# ============================================================
async def modo_actualizar(client, datos):
    juegos_existentes = {j["id"] for j in datos["juegos"]}
    ultimo_id = datos["ultimo_id"]
    
    if ultimo_id == 0:
        print("\n[PRIMERA EJECUCION] Escaneando todos los mensajes...")
    else:
        print(f"\n[ACTUALIZACION RAPIDA] Buscando nuevos despues del ID {ultimo_id}")
    
    nuevos = 0
    max_id = ultimo_id
    
    async for msg in client.iter_messages(CHAT_ID, min_id=ultimo_id):
        if not msg.photo or not msg.text:
            continue
        if msg.id in juegos_existentes:
            continue
        if msg.id in BLACKLIST_IDS:
            continue
        
        url_steam, app_id, slug = extraer_url_steam(msg)
        nombre = extraer_nombre_juego(msg.text, slug)
        if not nombre:
            continue
        
        # Comprobar coherencia nombre vs slug
        if app_id and slug and not nombres_coherentes(nombre, slug):
            print(f"  [INCOHERENCIA] '{nombre}' vs slug '{slug}' - descarto app_id")
            url_steam = None
            app_id = None
            slug = None
        
        datos["juegos"].append({
            "id": msg.id,
            "nombre": nombre,
            "url": construir_url_mensaje(CHAT_ID, msg.id),
            "url_steam": url_steam,
            "app_id": app_id,
            "imagen_local": False,
            "fecha": msg.date.isoformat() if msg.date else None
        })
        nuevos += 1
        if msg.id > max_id:
            max_id = msg.id
        print(f"  + {nombre}")
    
    datos["ultimo_id"] = max_id
    print(f"\nJuegos nuevos: {nuevos}")
    print(f"Total acumulado: {len(datos['juegos'])}")
    return nuevos, 0

async def modo_limpiar(client, datos):
    print("\n[LIMPIEZA COMPLETA] Verificando juegos existentes...")
    
    if not datos["juegos"]:
        return await modo_actualizar(client, datos)
    
    nuevos, _ = await modo_actualizar(client, datos)
    
    print("\nVerificando juegos antiguos...")
    ids_actuales = [j["id"] for j in datos["juegos"]]
    ids_validos = set()
    
    LOTE = 100
    for i in range(0, len(ids_actuales), LOTE):
        chunk = ids_actuales[i:i+LOTE]
        mensajes = await client.get_messages(CHAT_ID, ids=chunk)
        for msg, msg_id in zip(mensajes, chunk):
            if msg is not None:
                ids_validos.add(msg_id)
        print(f"  Verificados {min(i+LOTE, len(ids_actuales))}/{len(ids_actuales)}")
    
    antes = len(datos["juegos"])
    juegos_borrados = [j for j in datos["juegos"] if j["id"] not in ids_validos]
    datos["juegos"] = [j for j in datos["juegos"] if j["id"] in ids_validos]
    eliminados = antes - len(datos["juegos"])
    
    if juegos_borrados:
        print(f"\nJuegos eliminados:")
        for j in juegos_borrados:
            print(f"  - {j['nombre']}")
    
    print(f"\nNuevos: {nuevos} | Eliminados: {eliminados} | Total: {len(datos['juegos'])}")
    return nuevos, eliminados

# ============================================================
# MAIN
# ============================================================
async def ejecutar(modo):
    if not cargar_github_token():
        pedir_github_token()
    
    client = TelegramClient("session_squad277", API_ID, API_HASH)
    await client.start(phone=PHONE)
    print("Conectado a Telegram")
    cargar_blacklist()
    cargar_correcciones()
    if BLACKLIST_IDS:
        print(f"Blacklist cargada: {len(BLACKLIST_IDS)} IDs ignorados")
    if CORRECCIONES.get("ids_sin_steam") or CORRECCIONES.get("nombres_personalizados"):
        n_correc = len(CORRECCIONES.get("ids_sin_steam", [])) + len(CORRECCIONES.get("nombres_personalizados", {}))
        print(f"Correcciones manuales cargadas: {n_correc}")
    
    try:
        chat = await client.get_entity(CHAT_ID)
        print(f"Grupo: {chat.title}")
    except Exception as e:
        print(f"Error accediendo al grupo: {e}")
        return
    
    print("Conectando a GitHub...")
    try:
        repo = obtener_repo()
    except Exception as e:
        print(f"Error GitHub: {e}")
        return
    
    print("Verificando logo...")
    if subir_logo_github(repo):
        print("Logo OK")
    
    datos = cargar_datos()
    if datos.get("chat_id") and datos["chat_id"] != CHAT_ID:
        print("Detectado cambio de chat_id, reseteando lista")
        datos = {"juegos": [], "ultimo_id": 0, "chat_id": CHAT_ID}
    else:
        datos["chat_id"] = CHAT_ID
    
    if modo == "1":
        ids_antes = {j["id"] for j in datos["juegos"]}
        nuevos, eliminados = await modo_actualizar(client, datos)
        ids_despues = {j["id"] for j in datos["juegos"]}
        ids_nuevos_actualizacion = ids_despues - ids_antes
    elif modo == "2":
        ids_antes = {j["id"] for j in datos["juegos"]}
        nuevos, eliminados = await modo_limpiar(client, datos)
        ids_despues = {j["id"] for j in datos["juegos"]}
        ids_nuevos_actualizacion = ids_despues - ids_antes
    else:  # modo "3" - reprocesar
        print("\n[MODO REPROCESAR] Mejorando datos existentes")
        await reprocesar_juegos_existentes(client, datos)
        nuevos, eliminados = 0, 0
        ids_nuevos_actualizacion = set()
    
    if not ids_nuevos_actualizacion and "ultimas_subidas" in datos:
        ids_nuevos_actualizacion = set(datos.get("ultimas_subidas", []))
    elif ids_nuevos_actualizacion:
        datos["ultimas_subidas"] = list(ids_nuevos_actualizacion)
    
    if not datos["juegos"]:
        print("\nNo hay juegos para indexar.")
        guardar_datos(datos)
        await client.disconnect()
        return
    
    # Aplicar correcciones manuales a TODOS los juegos
    print("\nAplicando correcciones manuales...")
    for j in datos["juegos"]:
        aplicar_correcciones(j)
    
    img_subidas = await procesar_imagenes(client, repo, datos)
    if img_subidas > 0:
        print(f"Imagenes subidas a GitHub: {img_subidas}")
    
    print("\nGenerando HTML...")
    html = generar_html(datos["juegos"], ids_nuevos_actualizacion)
    
    print("Subiendo HTML a GitHub...")
    try:
        subir_html_github(repo, html)
        url = f"https://{GITHUB_USER}.github.io/{GITHUB_REPO}/"
        print(f"\n✅ Indice listo: {url}")
        print("(GitHub Pages tarda ~30 seg en publicar los cambios)")
        
        if nuevos > 0 or eliminados > 0:
            mensaje = f"📚 Indice SDCS actualizado\n\n{url}\n\n"
            if nuevos > 0:
                mensaje += f"➕ Nuevos: {nuevos}\n"
            if eliminados > 0:
                mensaje += f"➖ Eliminados: {eliminados}\n"
            mensaje += f"📦 Total: {len(datos['juegos'])}"
            await client.send_message("me", mensaje)
    except Exception as e:
        print(f"Error subiendo HTML: {e}")
    
    guardar_datos(datos)
    print("Datos guardados.")
    
    # Backups
    crear_backup_local()
    subir_backup_github(repo, datos)
    
    await client.disconnect()

def menu():
    print("=" * 50)
    print("  INDICE WEB SDCS - Squad_277")
    print("=" * 50)
    print()
    print("  [1] Actualizar (rapido) - Solo juegos nuevos")
    print("  [2] Limpieza completa  - Verifica todos los juegos")
    print("  [3] Reprocesar datos   - Mejora nombres, fechas, app_ids")
    print("  [0] Salir")
    print()
    while True:
        opcion = input("Selecciona una opcion: ").strip()
        if opcion in ("1", "2", "3", "0"):
            return opcion
        print("Opcion no valida.")

if __name__ == "__main__":
    opcion = menu()
    if opcion == "0":
        print("Saliendo...")
    else:
        asyncio.run(ejecutar(opcion))
        input("\nPulsa Enter para cerrar...")
