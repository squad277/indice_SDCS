"""
Anade URL HLS a los videos existentes.
Solo pide el campo movies de Steam (peticion ligera).
"""
import json
import time
import requests

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
}

ARCHIVO = "indice_datos_grupo.json"

print("=" * 60)
print("ANADIR URL HLS A VIDEOS EXISTENTES")
print("=" * 60)

with open(ARCHIVO, "r", encoding="utf-8") as f:
    datos = json.load(f)

# Solo juegos con steam_info y videos
juegos_con_videos = [j for j in datos["juegos"]
                     if j.get("steam_info", {}).get("videos")]

print(f"\nJuegos con videos a actualizar: {len(juegos_con_videos)}")
print(f"Tiempo estimado: ~{len(juegos_con_videos) * 1.5 / 60:.0f} minutos\n")

actualizados = 0
con_hls = 0
fallidos = 0

for i, juego in enumerate(juegos_con_videos):
    if i % 50 == 0:
        print(f"Progreso: {i}/{len(juegos_con_videos)} - Con HLS: {con_hls}")
    
    app_id = juego["app_id"]
    
    try:
        # Pedir solo el campo movies (peticion ligera)
        url = f"https://store.steampowered.com/api/appdetails?appids={app_id}&filters=movies"
        r = requests.get(url, headers=HEADERS, timeout=10)
        if r.status_code != 200:
            fallidos += 1
            time.sleep(1.5)
            continue
        
        data = r.json()
        d = data.get(str(app_id), {}).get("data", {})
        if not d:
            fallidos += 1
            time.sleep(1.5)
            continue
        
        movies_steam = d.get("movies", [])
        videos_actuales = juego["steam_info"]["videos"]
        
        # Asignar HLS a cada video existente (en orden)
        for idx_v, v_actual in enumerate(videos_actuales):
            if idx_v < len(movies_steam):
                v_steam = movies_steam[idx_v]
                hls = v_steam.get("hls_h264", "")
                v_actual["url_hls"] = hls
                if hls:
                    con_hls += 1
        
        actualizados += 1
        time.sleep(1.5)
        
        # Guardar parcial cada 100
        if (i + 1) % 100 == 0:
            with open(ARCHIVO, "w", encoding="utf-8") as f:
                json.dump(datos, f, ensure_ascii=False, indent=2)
    
    except Exception as e:
        fallidos += 1
        time.sleep(1.5)

# Guardar al final
with open(ARCHIVO, "w", encoding="utf-8") as f:
    json.dump(datos, f, ensure_ascii=False, indent=2)

print("\n" + "=" * 60)
print("RESUMEN")
print("=" * 60)
print(f"  Actualizados: {actualizados}")
print(f"  Videos con HLS: {con_hls}")
print(f"  Fallidos: {fallidos}")

print("\nAhora ejecuta indice_web.py opcion 1 para regenerar el HTML.")
input("\nPulsa Enter para cerrar...")
