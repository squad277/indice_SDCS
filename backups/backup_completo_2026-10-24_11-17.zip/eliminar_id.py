"""Elimina del JSON los IDs que esten en la blacklist
Ejecutar despues de anadir IDs nuevos a ids_ignorados.json"""
import json

with open("ids_ignorados.json", "r", encoding="utf-8") as f:
    blacklist = set(json.load(f))

with open("indice_datos_grupo.json", "r", encoding="utf-8") as f:
    datos = json.load(f)

antes = len(datos["juegos"])
juegos_borrados = [j for j in datos["juegos"] if j["id"] in blacklist]
datos["juegos"] = [j for j in datos["juegos"] if j["id"] not in blacklist]
despues = len(datos["juegos"])

# Tambien limpiar de ultimas_subidas
if "ultimas_subidas" in datos:
    datos["ultimas_subidas"] = [i for i in datos["ultimas_subidas"] if i not in blacklist]

print(f"Juegos antes: {antes}")
print(f"Juegos despues: {despues}")
print(f"Eliminados: {antes - despues}\n")

if juegos_borrados:
    print("Borrados del indice:")
    for j in juegos_borrados:
        print(f"  - ID {j['id']}: {j['nombre'][:60]}")

with open("indice_datos_grupo.json", "w", encoding="utf-8") as f:
    json.dump(datos, f, ensure_ascii=False, indent=2)

print("\nDatos guardados.")
print("Ahora ejecuta indice_web.py opcion 1 para subir los cambios.")
input("\nPulsa Enter para cerrar...")
