"""Diagnostico API Steam - probar diferentes formas de pedir info"""
import requests
import json

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
}

APP_ID = "1091500"  # Cyberpunk

print("=" * 60)
print("ESTRUCTURA REAL DEL CAMPO MOVIES")
print("=" * 60)

url = f"https://store.steampowered.com/api/appdetails?appids={APP_ID}&l=spanish&cc=es"
r = requests.get(url, headers=HEADERS, timeout=10)
data = r.json()
d = data.get(APP_ID, {}).get("data", {})

movies = d.get("movies", [])
print(f"\nTotal videos: {len(movies)}")

if movies:
    primer = movies[0]
    print(f"\n[PRIMER VIDEO COMPLETO]")
    print(json.dumps(primer, indent=2, ensure_ascii=False))

input("\nPulsa Enter para cerrar...")
