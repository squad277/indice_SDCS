"""Reprocesa un solo juego (lee el mensaje actualizado y actualiza sus datos)
SIN afectar las ultimas_subidas ni el resto del indice"""
import asyncio
import json
import re
from telethon import TelegramClient

API_ID = "***"  # tachado en el backup de GitHub
API_HASH = "***"  # tachado en el backup de GitHub
CHAT_ID = -1001634508656

# CAMBIA ESTE ID por el del juego a reprocesar
ID_A_REPROCESAR = 37333

REGEX_STEAM_APP = re.compile(r'store\.steampowered\.com/app/(\d+)(?:/([^/\s]+))?', re.IGNORECASE)
REGEX_URL = re.compile(r'https?://\S+')


def es_solo_url(linea):
    return bool(re.fullmatch(r'https?://\S+', linea.strip()))


def slug_a_nombre(slug):
    if not slug:
        return None
    nombre = slug.replace('_', ' ').replace('-', ' ')
    return re.sub(r'\s+', ' ', nombre).strip().title()


def extraer_url_steam(msg):
    if msg.entities:
        for entity in msg.entities:
            if hasattr(entity, 'url') and entity.url and 'store.steampowered.com' in entity.url:
                m = REGEX_STEAM_APP.search(entity.url)
                if m:
                    return entity.url, m.group(1), m.group(2)
    if msg.text:
        urls = REGEX_URL.findall(msg.text)
        for url in urls:
            m = REGEX_STEAM_APP.search(url)
            if m:
                return url, m.group(1), m.group(2)
    return None, None, None


def extraer_nombre_juego(texto, slug=None):
    if not texto:
        return None
    lineas = [l for l in texto.split('\n') if l.strip()]
    if not lineas:
        return None
    primera = lineas[0].strip()
    
    if es_solo_url(primera):
        if slug:
            return slug_a_nombre(slug).upper()
        return None
    
    primera_sin_url = REGEX_URL.sub('', primera).strip()
    if not primera_sin_url:
        if slug:
            return slug_a_nombre(slug).upper()
        return None
    
    nombre = re.sub(r'^[^\w]*', '', primera_sin_url).strip()
    nombre = nombre.strip("_").strip().rstrip("*").strip()
    if len(nombre) < 3:
        return None
    return nombre


async def main():
    client = TelegramClient("session_squad277", API_ID, API_HASH)
    await client.start()
    print("Conectado a Telegram\n")
    
    # Cargar JSON
    with open("indice_datos_grupo.json", "r", encoding="utf-8") as f:
        datos = json.load(f)
    
    # Buscar el juego
    juego = next((j for j in datos["juegos"] if j["id"] == ID_A_REPROCESAR), None)
    if not juego:
        print(f"No se encontro juego con ID {ID_A_REPROCESAR}")
        await client.disconnect()
        return
    
    print(f"ANTES:")
    print(f"  Nombre: {juego['nombre']}")
    print(f"  app_id: {juego.get('app_id')}")
    print(f"  url_steam: {juego.get('url_steam')}\n")
    
    # Leer mensaje actualizado de Telegram
    msg = await client.get_messages(CHAT_ID, ids=ID_A_REPROCESAR)
    if not msg:
        print("No se pudo leer el mensaje")
        await client.disconnect()
        return
    
    # Reprocesar
    url_steam, app_id, slug = extraer_url_steam(msg)
    nuevo_nombre = extraer_nombre_juego(msg.text or "", slug)
    
    if app_id:
        juego["app_id"] = app_id
        juego["url_steam"] = url_steam
    if nuevo_nombre:
        juego["nombre"] = nuevo_nombre
    if msg.date:
        juego["fecha"] = msg.date.isoformat()
    
    print(f"DESPUES:")
    print(f"  Nombre: {juego['nombre']}")
    print(f"  app_id: {juego.get('app_id')}")
    print(f"  url_steam: {juego.get('url_steam')}\n")
    
    # Guardar
    with open("indice_datos_grupo.json", "w", encoding="utf-8") as f:
        json.dump(datos, f, ensure_ascii=False, indent=2)
    
    print("Datos guardados.")
    print("\nAhora ejecuta indice_web.py opcion 1 para subir los cambios.")
    
    await client.disconnect()
    input("\nPulsa Enter para cerrar...")


if __name__ == "__main__":
    asyncio.run(main())
