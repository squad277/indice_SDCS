"""Test: probar URLs MP4 reconstruidas desde el ID del video"""
import requests

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
}

# IDs de videos que sabemos que existen (de Cyberpunk)
VIDEO_ID = "257082781"  # ID del primer trailer de Cyberpunk

# Patrones de URL conocidos para MP4 directo
patrones = [
    f"https://cdn.akamai.steamstatic.com/steam/apps/{VIDEO_ID}/movie480_vp9.webm",
    f"https://cdn.akamai.steamstatic.com/steam/apps/{VIDEO_ID}/movie480.webm",
    f"https://cdn.akamai.steamstatic.com/steam/apps/{VIDEO_ID}/movie480.mp4",
    f"https://cdn.akamai.steamstatic.com/steam/apps/{VIDEO_ID}/movie_max.webm",
    f"https://cdn.akamai.steamstatic.com/steam/apps/{VIDEO_ID}/movie_max.mp4",
    f"https://video.akamai.steamstatic.com/store_trailers/{VIDEO_ID}/movie480.mp4",
]

print("Probando URLs MP4/WEBM directas para el video ID", VIDEO_ID)
print("=" * 70)
for url in patrones:
    try:
        r = requests.head(url, headers=HEADERS, timeout=5, allow_redirects=True)
        size_kb = int(r.headers.get('content-length', 0)) // 1024
        status = "OK" if r.status_code == 200 else f"HTTP {r.status_code}"
        print(f"  [{status}] {url}")
        if size_kb > 0:
            print(f"          Tamaño: {size_kb} KB")
    except Exception as e:
        print(f"  [ERROR] {url}")
        print(f"          {str(e)[:80]}")

input("\nPulsa Enter para cerrar...")
