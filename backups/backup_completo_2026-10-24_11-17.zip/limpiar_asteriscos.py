"""
Limpia asteriscos ** y guiones __ de los nombres de juegos en el JSON
"""
import json
import re

with open("indice_datos_grupo.json", "r", encoding="utf-8") as f:
    datos = json.load(f)

print("=" * 60)
print("LIMPIEZA DE ASTERISCOS Y GUIONES EN NOMBRES")
print("=" * 60)

afectados = []

for juego in datos["juegos"]:
    nombre_original = juego["nombre"]
    nombre_limpio = nombre_original.replace("**", "").replace("__", "").strip()
    nombre_limpio = re.sub(r'\s+', ' ', nombre_limpio).strip()
    
    if nombre_limpio != nombre_original:
        afectados.append({
            "id": juego["id"],
            "antes": nombre_original,
            "despues": nombre_limpio
        })
        juego["nombre"] = nombre_limpio

if afectados:
    print(f"\nJuegos afectados: {len(afectados)}\n")
    for a in afectados[:30]:  # Mostrar maximo 30
        print(f"  ID {a['id']}")
        print(f"    Antes:   '{a['antes']}'")
        print(f"    Despues: '{a['despues']}'")
        print()
    
    if len(afectados) > 30:
        print(f"... y {len(afectados) - 30} mas")
    
    print("\n¿Guardar cambios? (SI/no): ", end="")
    respuesta = input().strip().upper()
    
    if respuesta == "SI":
        with open("indice_datos_grupo.json", "w", encoding="utf-8") as f:
            json.dump(datos, f, ensure_ascii=False, indent=2)
        print(f"\n✓ Guardados {len(afectados)} juegos limpios")
        print("\nAhora ejecuta indice_web.py opcion 1 para subir los cambios.")
    else:
        print("Cancelado. No se ha guardado nada.")
else:
    print("\n✓ No se encontraron juegos con asteriscos o guiones bajos")

input("\nPulsa Enter para cerrar...")
