"""
buscar_duplicados.py
Detecta juegos duplicados en indice_datos_grupo.json del proyecto Indice SDCS.

Modos de detección:
  1. DUPLICADOS LITERALES: mismo nombre exacto (tras limpieza básica)
  2. DUPLICADOS LÓGICOS: mismo nombre tras normalización agresiva
     (minúsculas, sin símbolos, sin "Remastered", "Edition", etc.)

Genera:
  - duplicados_literales.txt
  - duplicados_logicos.txt
  - duplicados_resumen.txt
"""

import json
import re
import unicodedata
from collections import defaultdict
from pathlib import Path

# ----------------------------------------------------------------------------
# Configuración
# ----------------------------------------------------------------------------
RUTA_JSON = Path(r"C:\Users\Lenovo\Downloads\BOT TELEGRAM 3.0\indice_datos_grupo.json")
RUTA_SALIDA = Path(r"C:\Users\Lenovo\Downloads\BOT TELEGRAM 3.0")

# Palabras / sufijos que se ignoran en la normalización agresiva
SUFIJOS_IGNORAR = [
    "remastered", "remaster", "remake",
    "definitive edition", "definitive",
    "complete edition", "complete",
    "ultimate edition", "ultimate",
    "deluxe edition", "deluxe",
    "gold edition", "gold",
    "game of the year edition", "game of the year", "goty",
    "enhanced edition", "enhanced",
    "anniversary edition", "anniversary",
    "directors cut", "director's cut",
    "extended edition", "extended",
    "special edition", "special",
    "premium edition", "premium",
    "standard edition", "standard",
    "edition",
]


def limpiar_basico(nombre: str) -> str:
    """Limpieza mínima: trim + colapsar espacios + sin asteriscos/underscores."""
    if not nombre:
        return ""
    s = nombre.replace("*", "").replace("_", " ")
    s = re.sub(r"\s+", " ", s).strip()
    return s


def normalizar_agresivo(nombre: str) -> str:
    """Normalización agresiva para detectar duplicados lógicos."""
    if not nombre:
        return ""
    # Pasar a minúsculas
    s = nombre.lower()
    # Quitar acentos
    s = unicodedata.normalize("NFKD", s)
    s = "".join(c for c in s if not unicodedata.combining(c))
    # Quitar símbolos comunes (™, ®, ©, etc.) y puntuación
    s = re.sub(r"[^\w\s]", " ", s)
    # Colapsar espacios
    s = re.sub(r"\s+", " ", s).strip()
    # Quitar sufijos de ediciones
    for sufijo in SUFIJOS_IGNORAR:
        # Eliminar al final
        if s.endswith(" " + sufijo):
            s = s[: -len(sufijo) - 1].strip()
        # Eliminar en medio (entre espacios)
        s = re.sub(r"\b" + re.escape(sufijo) + r"\b", "", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s


def cargar_juegos(ruta: Path):
    """Carga el JSON y devuelve la lista de juegos."""
    with ruta.open("r", encoding="utf-8") as f:
        datos = json.load(f)

    # El JSON puede ser una lista o un dict con clave "juegos" / "mensajes"
    if isinstance(datos, list):
        return datos
    if isinstance(datos, dict):
        # Probar claves habituales
        for clave in ("juegos", "mensajes", "messages", "games", "data"):
            if clave in datos and isinstance(datos[clave], list):
                return datos[clave]
        # Si no, devolver los valores si son una lista de juegos
        valores = list(datos.values())
        if valores and isinstance(valores[0], dict):
            return valores
    raise ValueError("No se pudo identificar la lista de juegos en el JSON")


def detectar_duplicados(juegos, modo: str):
    """
    Agrupa los juegos por nombre normalizado.
    modo: "literal" o "logico"
    Devuelve dict { nombre_clave: [juegos] } solo con los que tienen >1.
    """
    func_norm = limpiar_basico if modo == "literal" else normalizar_agresivo
    grupos = defaultdict(list)
    for j in juegos:
        nombre_original = j.get("nombre") or j.get("name") or j.get("titulo") or ""
        clave = func_norm(nombre_original)
        if not clave:
            continue
        grupos[clave].append(j)
    return {k: v for k, v in grupos.items() if len(v) > 1}


def formato_juego(j):
    """Línea representativa de un juego para el listado."""
    nombre = j.get("nombre") or j.get("name") or j.get("titulo") or "(sin nombre)"
    msg_id = j.get("id") or j.get("message_id") or j.get("msg_id") or "?"
    app_id = j.get("app_id") or j.get("appid") or ""
    fecha = j.get("fecha") or j.get("date") or ""
    extras = []
    if app_id:
        extras.append(f"app_id={app_id}")
    if fecha:
        extras.append(f"fecha={fecha}")
    extras_str = " | " + " | ".join(extras) if extras else ""
    return f"  - [{msg_id}] {nombre}{extras_str}"


def escribir_listado(grupos: dict, ruta_salida: Path, titulo: str):
    """Escribe el listado de duplicados a un archivo."""
    # Ordenar por número de duplicados desc, luego nombre
    items = sorted(grupos.items(), key=lambda x: (-len(x[1]), x[0]))
    total_grupos = len(items)
    total_juegos = sum(len(v) for v in grupos.values())

    with ruta_salida.open("w", encoding="utf-8") as f:
        f.write(f"=== {titulo} ===\n")
        f.write(f"Grupos de duplicados: {total_grupos}\n")
        f.write(f"Juegos implicados:    {total_juegos}\n")
        f.write(f"Excedentes (a podar): {total_juegos - total_grupos}\n")
        f.write("=" * 60 + "\n\n")
        for clave, lista in items:
            f.write(f"[{len(lista)}x] {clave}\n")
            for j in lista:
                f.write(formato_juego(j) + "\n")
            f.write("\n")


def main():
    print(f"Cargando {RUTA_JSON} ...")
    juegos = cargar_juegos(RUTA_JSON)
    print(f"Total juegos: {len(juegos)}\n")

    # ---- Duplicados literales ----
    print("Detectando duplicados LITERALES (mismo nombre exacto)...")
    dup_lit = detectar_duplicados(juegos, "literal")
    salida_lit = RUTA_SALIDA / "duplicados_literales.txt"
    escribir_listado(dup_lit, salida_lit, "DUPLICADOS LITERALES (mismo nombre exacto)")
    print(f"  Grupos: {len(dup_lit)}  ->  {salida_lit}")

    # ---- Duplicados lógicos ----
    print("\nDetectando duplicados LÓGICOS (normalizando edición/remaster/símbolos)...")
    dup_log = detectar_duplicados(juegos, "logico")
    salida_log = RUTA_SALIDA / "duplicados_logicos.txt"
    escribir_listado(dup_log, salida_log, "DUPLICADOS LÓGICOS (normalización agresiva)")
    print(f"  Grupos: {len(dup_log)}  ->  {salida_log}")

    # ---- Resumen ----
    salida_res = RUTA_SALIDA / "duplicados_resumen.txt"
    with salida_res.open("w", encoding="utf-8") as f:
        f.write("=== RESUMEN DUPLICADOS INDICE SDCS ===\n\n")
        f.write(f"Total juegos en índice:        {len(juegos)}\n\n")
        f.write(f"Duplicados literales:\n")
        f.write(f"  Grupos:    {len(dup_lit)}\n")
        f.write(f"  Juegos:    {sum(len(v) for v in dup_lit.values())}\n")
        f.write(f"  Excedentes a podar: {sum(len(v) for v in dup_lit.values()) - len(dup_lit)}\n\n")
        f.write(f"Duplicados lógicos (incluye los literales):\n")
        f.write(f"  Grupos:    {len(dup_log)}\n")
        f.write(f"  Juegos:    {sum(len(v) for v in dup_log.values())}\n")
        f.write(f"  Excedentes a podar: {sum(len(v) for v in dup_log.values()) - len(dup_log)}\n")
    print(f"\nResumen: {salida_res}")
    print("\nListo. Revisa los .txt en la carpeta del proyecto.")


if __name__ == "__main__":
    main()
