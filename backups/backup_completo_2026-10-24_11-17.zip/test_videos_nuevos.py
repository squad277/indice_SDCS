"""Verifica las URLs de video de los 21 nuevos juegos"""
import json
import requests

HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}

with open("indice_datos_grupo.json", "r", encoding="utf-8") as f:
    datos = json.load(f)

# Cargar IDs de las ultimas subidas
ultimas_ids = set(datos.get("ultimas_subidas", []))

# Filtrar juegos de las ultimas subidas con videos
nuevos_con_video = [j for j in datos["juegos"]
                    if j["id"] in ultimas_ids
                    and j.get("steam_info", {}).get("videos")]

print(f"Ultimas subidas: {len(ultimas_ids)}")
print(f"Con videos: {len(nuevos_con_video)}\n")
print("=" * 80)
print("PROBANDO TODAS LAS URLs DE LOS NUEVOS JUEGOS")
print("=" * 80)

for j in nuevos_con_video:
    nombre = j["nombre"][:40]
    print(f"\n>>> {nombre}")
    
    for i, v in enumerate(j["steam_info"]["videos"]):
        print(f"  Video {i+1}:")
        for clave in ["url", "url_max", "url_webm"]:
            url = v.get(clave, "")
            if not url:
                print(f"    [{clave}] (no existe en JSON)")
                continue
            try:
                r = requests.head(url, headers=HEADERS, timeout=5, allow_redirects=True)
                size = int(r.headers.get('content-length', 0)) // 1024
                if r.status_code == 200:
                    print(f"    [OK {size:>6} KB] {clave}")
                else:
                    print(f"    [HTTP {r.status_code}] {clave}")
            except Exception as e:
                print(f"    [ERROR] {clave}: {str(e)[:40]}")

input("\nPulsa Enter para cerrar...")
