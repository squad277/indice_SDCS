"""Verifica que se haya guardado info de Steam con videos"""
import json

with open("indice_datos_grupo.json", "r", encoding="utf-8") as f:
    datos = json.load(f)

juegos = datos["juegos"]

# Estadisticas generales
con_app_id = [j for j in juegos if j.get("app_id")]
con_steam_info = [j for j in juegos if j.get("steam_info") and not j.get("steam_info", {}).get("error")]
con_videos = [j for j in juegos if j.get("steam_info") and j.get("steam_info", {}).get("videos")]

print("=" * 60)
print("VERIFICACION DE INFO STEAM EN JSON")
print("=" * 60)
print(f"\nTotal juegos: {len(juegos)}")
print(f"Con app_id: {len(con_app_id)}")
print(f"Con steam_info: {len(con_steam_info)}")
print(f"Con videos guardados: {len(con_videos)}")

# Buscar MOTOGP, Cyberpunk, GTA
print("\n" + "=" * 60)
print("BUSCANDO JUEGOS POPULARES CON VIDEOS")
print("=" * 60)

palabras_buscar = ["MOTOGP", "CYBERPUNK", "GTA V", "ELDEN", "WITCHER", "DOOM", "FIFA"]
encontrados = 0
for palabra in palabras_buscar:
    for j in juegos:
        if palabra in j["nombre"].upper():
            si = j.get("steam_info", {})
            if si and not si.get("error"):
                videos = si.get("videos", [])
                screenshots = si.get("screenshots", [])
                generos = si.get("generos", [])
                print(f"\n  {j['nombre']}")
                print(f"    app_id: {j.get('app_id')}")
                print(f"    Generos: {generos}")
                print(f"    Screenshots: {len(screenshots)}")
                print(f"    VIDEOS: {len(videos)}")
                if videos:
                    for v in videos:
                        url = v.get('url', '')[:80]
                        print(f"      - URL: {url}...")
                        thumb = v.get('thumb', '')[:80]
                        print(f"        Thumb: {thumb}...")
                encontrados += 1
                break

if encontrados == 0:
    print("No se encontraron los juegos populares")

# Mostrar los primeros 5 con videos
print("\n" + "=" * 60)
print("PRIMEROS 5 JUEGOS CON VIDEOS GUARDADOS")
print("=" * 60)
for i, j in enumerate(con_videos[:5]):
    print(f"\n  {j['nombre']}")
    print(f"    Videos: {len(j['steam_info']['videos'])}")
    if j['steam_info']['videos']:
        v = j['steam_info']['videos'][0]
        print(f"    Primera URL: {v.get('url', '')[:80]}")

input("\nPulsa Enter para cerrar...")
