"""
COPIA DE SEGURIDAD COMPLETA del proyecto Indice SDCS
Crea un ZIP con todos los archivos esenciales + sube backup adicional a GitHub
"""
import os
import zipfile
import json
import shutil
import re
from datetime import datetime
from github import Github

# Archivos del proyecto: todo lo que hay en la carpeta raiz (scripts, datos,
# informes, logo...). Solo se excluyen los ZIP y la carpeta de backups.
def listar_archivos_proyecto():
    return sorted(
        f for f in os.listdir(".")
        if os.path.isfile(f) and not f.lower().endswith(".zip")
    )

ARCHIVOS_PROYECTO = listar_archivos_proyecto()

# Archivos sensibles que NUNCA suben a GitHub
# (sí van en el ZIP local pero el ZIP de GitHub los excluye)
ARCHIVOS_SENSIBLES = [
    "github_token.txt",
    "session_squad277.session",
]

# En los scripts .py del ZIP de GitHub se tachan estas credenciales
# (API_ID / API_HASH de Telegram van escritas en indice_web.py y reprocesar_uno.py)
PATRON_CREDENCIAL_PY = re.compile(r'^(\s*(?:API_ID|API_HASH)\s*=\s*).+$', re.MULTILINE)

# Cualquier cosa con pinta de secreto: si aparece en el ZIP de GitHub NO se sube
# (GitHub bloquea la subida si detecta tokens, y el repo es publico)
PATRON_SECRETO = re.compile(
    r'ghp_[A-Za-z0-9]{36}'
    r'|github_pat_[A-Za-z0-9_]{50,}'
    r'|gh[ousr]_[A-Za-z0-9]{36}'
    r'|\b\d{8,10}:AA[A-Za-z0-9_-]{30,}'    # token de bot de Telegram
    r'''|(?:API_HASH|api_hash)\s*=\s*["'][0-9a-f]{32}'''
)

GITHUB_USER = "squad277"
GITHUB_REPO = "indice_SDCS"

def crear_zip_local():
    """Crea un ZIP con todos los archivos esenciales (incluido el token) en local"""
    fecha = datetime.now().strftime("%Y-%m-%d_%H-%M")
    carpeta_backup = "BACKUPS_PROYECTO"
    os.makedirs(carpeta_backup, exist_ok=True)
    
    nombre_zip = os.path.join(carpeta_backup, f"backup_completo_{fecha}.zip")
    
    print(f"Creando backup LOCAL (con credenciales): {nombre_zip}\n")
    
    archivos_incluidos = 0
    with zipfile.ZipFile(nombre_zip, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for archivo in ARCHIVOS_PROYECTO:
            if os.path.exists(archivo):
                zipf.write(archivo)
                tam = os.path.getsize(archivo)
                marca = " [SENSIBLE]" if archivo in ARCHIVOS_SENSIBLES else ""
                print(f"  + {archivo} ({tam:,} bytes){marca}")
                archivos_incluidos += 1
            else:
                print(f"  ! No encontrado: {archivo}")
    
    tam_zip = os.path.getsize(nombre_zip)
    print(f"\nZIP local creado: {nombre_zip}")
    print(f"Tamaño total: {tam_zip:,} bytes ({tam_zip/1024:.1f} KB)")
    print(f"Archivos incluidos: {archivos_incluidos}/{len(ARCHIVOS_PROYECTO)}")
    
    return nombre_zip, tam_zip


def crear_zip_github():
    """Crea un ZIP SIN credenciales para subir a GitHub de forma segura"""
    fecha = datetime.now().strftime("%Y-%m-%d_%H-%M")
    nombre_zip_temp = f"backup_completo_{fecha}.zip"
    
    print(f"\nCreando backup PARA GITHUB (sin credenciales)...")
    
    archivos_incluidos = 0
    with zipfile.ZipFile(nombre_zip_temp, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for archivo in ARCHIVOS_PROYECTO:
            # EXCLUIR archivos sensibles
            if archivo in ARCHIVOS_SENSIBLES:
                print(f"  - {archivo} EXCLUIDO (no se sube a GitHub)")
                continue
            if os.path.exists(archivo):
                if archivo.endswith(".py"):
                    with open(archivo, encoding="utf-8") as f:
                        codigo = f.read()
                    codigo, n = PATRON_CREDENCIAL_PY.subn(r'\1"***"  # tachado en el backup de GitHub', codigo)
                    zipf.writestr(archivo, codigo)
                    marca = f" [{n} credenciales tachadas]" if n else ""
                else:
                    zipf.write(archivo)
                    marca = ""
                tam = os.path.getsize(archivo)
                print(f"  + {archivo} ({tam:,} bytes){marca}")
                archivos_incluidos += 1
    
    tam_zip = os.path.getsize(nombre_zip_temp)
    print(f"\nZIP para GitHub creado (temporal)")
    print(f"Tamaño total: {tam_zip:,} bytes ({tam_zip/1024:.1f} KB)")
    print(f"Archivos incluidos: {archivos_incluidos}/{len(ARCHIVOS_PROYECTO) - len(ARCHIVOS_SENSIBLES)}")
    
    return nombre_zip_temp, tam_zip

def zip_sin_secretos(nombre_zip):
    """Revisa todo el contenido del ZIP de GitHub. Devuelve False si encuentra algun secreto"""
    print("\nRevisando que el ZIP de GitHub no lleve tokens...")
    limpio = True
    with zipfile.ZipFile(nombre_zip) as z:
        for nombre in z.namelist():
            texto = z.read(nombre).decode("utf-8", errors="ignore")
            encontrados = PATRON_SECRETO.findall(texto)
            if encontrados:
                limpio = False
                print(f"  ! {nombre}: {len(encontrados)} posible(s) secreto(s)")
    print("  OK, ningun token encontrado" if limpio else "  NO se sube a GitHub")
    return limpio

def subir_a_github(nombre_zip, tam_zip):
    """Sube el ZIP a la carpeta backups del repositorio GitHub"""
    print("\n" + "=" * 50)
    print("Subiendo backup a GitHub...")
    print("=" * 50)
    
    if not os.path.exists("github_token.txt"):
        print("No se encontro github_token.txt, omitiendo subida a GitHub")
        return False
    
    with open("github_token.txt") as f:
        token = f.read().strip()
    
    try:
        g = Github(token)
        repo = g.get_user().get_repo(GITHUB_REPO)
        
        # GitHub tiene limite de 100MB por archivo (la API admite hasta ~25MB por subida)
        with open(nombre_zip, "rb") as f:
            contenido = f.read()
        
        ruta_remota = f"backups/{os.path.basename(nombre_zip)}"
        mensaje = f"Backup completo {datetime.now().strftime('%Y-%m-%d %H:%M')}"
        
        try:
            archivo = repo.get_contents(ruta_remota)
            repo.update_file(ruta_remota, mensaje, contenido, archivo.sha)
        except:
            repo.create_file(ruta_remota, mensaje, contenido)
        
        print(f"\n✅ Backup subido a GitHub:")
        print(f"   https://github.com/{GITHUB_USER}/{GITHUB_REPO}/blob/main/{ruta_remota}")
        return True
    except Exception as e:
        print(f"\n❌ Error subiendo a GitHub: {e}")
        return False

def listar_backups_existentes():
    """Lista los backups locales existentes"""
    carpeta_backup = "BACKUPS_PROYECTO"
    if not os.path.exists(carpeta_backup):
        return
    
    print("\n" + "=" * 50)
    print("BACKUPS EXISTENTES EN TU PC:")
    print("=" * 50)
    
    archivos = sorted(os.listdir(carpeta_backup))
    for f in archivos:
        ruta = os.path.join(carpeta_backup, f)
        tam = os.path.getsize(ruta)
        print(f"  - {f} ({tam:,} bytes)")
    
    print(f"\nTotal: {len(archivos)} backups")

def main():
    print("=" * 50)
    print("COPIA DE SEGURIDAD COMPLETA")
    print("=" * 50)
    print(f"\nFecha: {datetime.now().strftime('%d/%m/%Y %H:%M')}\n")
    
    # 1. Crear ZIP local (con credenciales)
    nombre_zip_local, tam_zip_local = crear_zip_local()
    
    # 2. Crear ZIP para GitHub (sin credenciales)
    nombre_zip_github, tam_zip_github = crear_zip_github()
    
    # 3. Subir el ZIP de GitHub (solo si no lleva ningun token)
    if zip_sin_secretos(nombre_zip_github):
        subir_a_github(nombre_zip_github, tam_zip_github)
    
    # 4. Borrar el ZIP temporal de GitHub
    if os.path.exists(nombre_zip_github):
        os.remove(nombre_zip_github)
        print("ZIP temporal eliminado de tu PC")
    
    # 5. Listar backups existentes
    listar_backups_existentes()
    
    print("\n" + "=" * 50)
    print("✅ BACKUP COMPLETADO")
    print("=" * 50)
    print("\nTu proyecto esta respaldado en:")
    print("  1. Tu PC: carpeta BACKUPS_PROYECTO/ (con credenciales)")
    print("  2. GitHub: backups/ del repositorio (SIN credenciales)")
    print("\nPuedes recuperar todo en cualquier momento descomprimiendo el ZIP.")
    
    input("\nPulsa Enter para cerrar...")

if __name__ == "__main__":
    main()
