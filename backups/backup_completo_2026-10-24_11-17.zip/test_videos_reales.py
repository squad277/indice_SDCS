"""Verifica si las URLs de video MP4 reconstruidas funcionan realmente"""
import json
import requests
import random

HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}

with open("indice_datos_grupo.json", "r", encoding="utf-8") as f:
    datos = json.load(f)

con_videos = [j for j in datos["juegos"]
              if j.get("steam_info") and j.get("steam_info", {}).get("videos")]

print(f"Total juegos con videos: {len(con_videos)}\n")

# Probar 10 al azar
muestra = random.sample(con_videos, min(10, len(con_videos)))

print("=" * 70)
print("PROBANDO 10 URLs DE VIDEO AL AZAR")
print("=" * 70)

ok = 0
fail = 0
for j in muestra:
    nombre = j["nombre"][:40]
    video = j["steam_info"]["videos"][0]
    url = video["url"]
    
    try:
        r = requests.head(url, headers=HEADERS, timeout=8, allow_redirects=True)
        if r.status_code == 200:
            size = int(r.headers.get('content-length', 0)) // 1024
            print(f"  [OK {size:>6} KB] {nombre}")
            ok += 1
        else:
            print(f"  [HTTP {r.status_code}] {nombre}")
            print(f"             URL: {url}")
            fail += 1
    except Exception as e:
        print(f"  [ERROR] {nombre}: {str(e)[:50]}")
        fail += 1

print(f"\n=== Resultado: {ok}/{len(muestra)} OK, {fail} fallidos ===")
input("\nPulsa Enter para cerrar...")
