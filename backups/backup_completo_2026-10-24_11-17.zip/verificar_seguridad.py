"""
Verifica que el token NO aparezca en archivos sensibles
"""
import os
import re
import json

ARCHIVOS_A_REVISAR = [
    "indice_datos_grupo.json",
    "indice_datos_grupo.backup.json",
    "correcciones_manuales.json",
    "ids_ignorados.json",
    "indice_web.py",
    "sdcs_manager.py",
    "duplicados.py",
    "estadisticas.py",
    "backup_completo.py",
    "eliminar_id.py",
    "reprocesar_uno.py",
]

# Patron de token de GitHub (clasicos empiezan por ghp_ + 36 chars)
PATRON_TOKEN = re.compile(r'ghp_[A-Za-z0-9]{36,}')
PATRON_TOKEN_NUEVO = re.compile(r'github_pat_[A-Za-z0-9_]{82,}')

print("=" * 60)
print("REVISION DE SEGURIDAD - Buscando tokens expuestos")
print("=" * 60)

problemas = []

for archivo in ARCHIVOS_A_REVISAR:
    if not os.path.exists(archivo):
        continue
    try:
        with open(archivo, "r", encoding="utf-8", errors="replace") as f:
            contenido = f.read()
        
        tokens_clasicos = PATRON_TOKEN.findall(contenido)
        tokens_nuevos = PATRON_TOKEN_NUEVO.findall(contenido)
        
        if tokens_clasicos or tokens_nuevos:
            problemas.append(archivo)
            print(f"\n⚠️  {archivo} CONTIENE TOKENS:")
            for t in tokens_clasicos + tokens_nuevos:
                print(f"   {t[:15]}...{t[-5:]}")
        else:
            print(f"  ✓ {archivo} OK")
    except Exception as e:
        print(f"  ? {archivo} (error leyendo: {e})")

# Revisar carpeta BACKUPS_PROYECTO
print("\n" + "=" * 60)
print("Revisando BACKUPS_PROYECTO/...")
print("=" * 60)
import zipfile
if os.path.exists("BACKUPS_PROYECTO"):
    for f in os.listdir("BACKUPS_PROYECTO"):
        if f.endswith(".zip"):
            ruta = os.path.join("BACKUPS_PROYECTO", f)
            try:
                with zipfile.ZipFile(ruta, "r") as z:
                    nombres = z.namelist()
                    if "github_token.txt" in nombres:
                        print(f"⚠️  {ruta} contiene github_token.txt")
                        problemas.append(ruta)
                    else:
                        print(f"  ✓ {ruta}")
            except Exception as e:
                print(f"  ? {ruta} ({e})")

print("\n" + "=" * 60)
if problemas:
    print(f"⚠️  PROBLEMAS DETECTADOS: {len(problemas)} archivos")
    print("\nEstos archivos NO deben subirse a GitHub.")
else:
    print("✓ TODO LIMPIO - No se encontraron tokens en archivos del proyecto")

print("=" * 60)
input("\nPulsa Enter para cerrar...")
