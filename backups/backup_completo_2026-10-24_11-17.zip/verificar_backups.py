"""
Verifica el estado de todos los backups (locales + listado del proyecto)
"""
import os
import zipfile
import json
from datetime import datetime

print("=" * 60)
print("ESTADO DE BACKUPS - SDCS")
print("=" * 60)

# === 1. BACKUPS LOCALES ===
print("\n[1] BACKUPS LOCALES (en BACKUPS_PROYECTO/)")
print("-" * 60)

if os.path.exists("BACKUPS_PROYECTO"):
    zips = sorted([f for f in os.listdir("BACKUPS_PROYECTO") if f.endswith(".zip")])
    print(f"Total backups: {len(zips)}\n")
    
    for f in zips:
        ruta = os.path.join("BACKUPS_PROYECTO", f)
        tam = os.path.getsize(ruta)
        mtime = datetime.fromtimestamp(os.path.getmtime(ruta))
        
        try:
            with zipfile.ZipFile(ruta, 'r') as z:
                nombres = z.namelist()
                tiene_token = 'github_token.txt' in nombres
                tiene_sesion = 'session_squad277.session' in nombres
                tiene_json = 'indice_datos_grupo.json' in nombres
        except:
            nombres = []
            tiene_token = False
            tiene_sesion = False
            tiene_json = False
        
        print(f"  {f}")
        print(f"    Fecha:   {mtime.strftime('%d/%m/%Y %H:%M')}")
        print(f"    Tamaño:  {tam:,} bytes ({tam/1024:.1f} KB)")
        print(f"    Archivos: {len(nombres)}")
        print(f"    JSON datos:    {'SI' if tiene_json else 'NO'}")
        print(f"    Token GitHub:  {'SI (ok local)' if tiene_token else 'NO'}")
        print(f"    Sesion Telegram: {'SI (ok local)' if tiene_sesion else 'NO'}")
        print()
else:
    print("  ⚠️  No existe la carpeta BACKUPS_PROYECTO/")

# === 2. BACKUP LOCAL DEL JSON ===
print("\n[2] BACKUP DEL JSON (indice_datos_grupo.backup.json)")
print("-" * 60)
if os.path.exists("indice_datos_grupo.backup.json"):
    tam = os.path.getsize("indice_datos_grupo.backup.json")
    mtime = datetime.fromtimestamp(os.path.getmtime("indice_datos_grupo.backup.json"))
    try:
        with open("indice_datos_grupo.backup.json", "r", encoding="utf-8") as f:
            datos = json.load(f)
        n_juegos = len(datos.get("juegos", []))
        print(f"  ✓ Existe")
        print(f"  Fecha:   {mtime.strftime('%d/%m/%Y %H:%M')}")
        print(f"  Tamaño:  {tam:,} bytes ({tam/1024:.1f} KB)")
        print(f"  Juegos:  {n_juegos}")
    except Exception as e:
        print(f"  ⚠️  Error leyendo: {e}")
else:
    print("  ⚠️  NO existe")

# === 3. JSON ACTUAL ===
print("\n[3] JSON ACTUAL (indice_datos_grupo.json)")
print("-" * 60)
if os.path.exists("indice_datos_grupo.json"):
    tam = os.path.getsize("indice_datos_grupo.json")
    mtime = datetime.fromtimestamp(os.path.getmtime("indice_datos_grupo.json"))
    try:
        with open("indice_datos_grupo.json", "r", encoding="utf-8") as f:
            datos = json.load(f)
        n_juegos = len(datos.get("juegos", []))
        ultimas = len(datos.get("ultimas_subidas", []))
        print(f"  ✓ Existe")
        print(f"  Fecha:   {mtime.strftime('%d/%m/%Y %H:%M')}")
        print(f"  Tamaño:  {tam:,} bytes ({tam/1024:.1f} KB)")
        print(f"  Juegos:  {n_juegos}")
        print(f"  Ultimas subidas: {ultimas}")
    except Exception as e:
        print(f"  ⚠️  Error leyendo: {e}")

# === 4. TOKEN ===
print("\n[4] TOKEN GITHUB")
print("-" * 60)
if os.path.exists("github_token.txt"):
    with open("github_token.txt") as f:
        token = f.read().strip()
    if token:
        print(f"  ✓ Token existe ({len(token)} caracteres)")
        print(f"  [Por seguridad, no se muestra ningún fragmento del token]")
    else:
        print(f"  ⚠️  Archivo vacio")
else:
    print(f"  ⚠️  NO existe github_token.txt")

# === 5. RESUMEN ===
print("\n" + "=" * 60)
print("RESUMEN")
print("=" * 60)

n_zips = len(zips) if 'zips' in dir() else 0
print(f"\n✓ Tienes {n_zips} backups ZIP locales")
print("✓ Tienes backup local del JSON (.backup.json)")
print("✓ GitHub tiene backup del JSON en backups/indice_datos_grupo.json")

print("\n[NOTA]: Los ZIPs locales contienen el TOKEN (es seguro, no salen de tu PC)")
print("[NOTA]: Los backups en GitHub NO contienen el token (asi GitHub no lo revoca)")

input("\nPulsa Enter para cerrar...")
