"""
LIMPIA TODOS LOS BACKUPS ANTIGUOS DEL REPOSITORIO GITHUB
Estos contienen el token revocado y deben eliminarse.
"""
import os
from github import Github

GITHUB_USER = "squad277"
GITHUB_REPO = "indice_SDCS"

def main():
    print("=" * 60)
    print("LIMPIEZA DE BACKUPS ANTIGUOS EN GITHUB")
    print("=" * 60)
    
    if not os.path.exists("github_token.txt"):
        print("\n❌ No se encontro github_token.txt")
        print("Tienes que generar un nuevo token primero")
        input("\nPulsa Enter para cerrar...")
        return
    
    with open("github_token.txt") as f:
        token = f.read().strip()
    
    if not token:
        print("\n❌ El archivo github_token.txt esta vacio")
        input("\nPulsa Enter para cerrar...")
        return
    
    try:
        g = Github(token)
        repo = g.get_user().get_repo(GITHUB_REPO)
        print(f"\nConectado a {GITHUB_USER}/{GITHUB_REPO}")
    except Exception as e:
        print(f"\n❌ Error de autenticacion: {e}")
        print("Comprueba que el token nuevo sea valido")
        input("\nPulsa Enter para cerrar...")
        return
    
    # Listar contenido de backups/
    try:
        contenidos = repo.get_contents("backups")
    except:
        print("\nLa carpeta backups/ no existe en el repositorio. Nada que limpiar.")
        input("\nPulsa Enter para cerrar...")
        return
    
    # Filtrar solo los .zip
    zips_antiguos = [c for c in contenidos if c.name.endswith(".zip")]
    json_backup = [c for c in contenidos if c.name.endswith(".json")]
    
    print(f"\nEncontrados {len(zips_antiguos)} ZIPs antiguos:")
    for z in zips_antiguos:
        print(f"  - {z.name} ({z.size:,} bytes)")
    
    if json_backup:
        print(f"\nTambien hay {len(json_backup)} backups JSON (estos NO se borran):")
        for j in json_backup:
            print(f"  - {j.name} (no contiene credenciales)")
    
    if not zips_antiguos:
        print("\nNo hay ZIPs antiguos para borrar.")
        input("\nPulsa Enter para cerrar...")
        return
    
    print(f"\n⚠️  Estos ZIPs contienen el token REVOCADO y hay que borrarlos.")
    respuesta = input("\n¿Confirmar borrado de los ZIPs? (SI/no): ").strip().upper()
    if respuesta != "SI":
        print("Cancelado.")
        input("Pulsa Enter para cerrar...")
        return
    
    # Borrar uno a uno
    borrados = 0
    for z in zips_antiguos:
        try:
            repo.delete_file(z.path, f"Limpiar backup antiguo: {z.name}", z.sha)
            print(f"  ✓ Borrado: {z.name}")
            borrados += 1
        except Exception as e:
            print(f"  ✗ Error con {z.name}: {e}")
    
    print(f"\n=== Terminado: {borrados}/{len(zips_antiguos)} ZIPs eliminados de GitHub ===")
    print("\nAhora puedes ejecutar backup_completo.py para crear backups nuevos seguros.")
    input("\nPulsa Enter para cerrar...")


if __name__ == "__main__":
    main()
