"""
Anade URLs de fallback (max y webm) a los videos ya guardados.
NO llama a Steam, solo extrae el video_id de la URL ya guardada.
Es instantaneo (1-2 segundos).
"""
import json
import re

ARCHIVO = "indice_datos_grupo.json"

print("Cargando datos...")
with open(ARCHIVO, "r", encoding="utf-8") as f:
    datos = json.load(f)

# Patron para extraer el video_id de la URL
# Ejemplo: https://cdn.akamai.steamstatic.com/steam/apps/257082781/movie480.mp4
PATRON = re.compile(r'/apps/(\d+)/movie480\.mp4')

actualizados = 0
total_videos = 0

for j in datos["juegos"]:
    si = j.get("steam_info")
    if not si or si.get("error"):
        continue
    
    videos = si.get("videos", [])
    if not videos:
        continue
    
    for v in videos:
        url_original = v.get("url", "")
        m = PATRON.search(url_original)
        if m:
            video_id = m.group(1)
            v["url_max"] = f"https://cdn.akamai.steamstatic.com/steam/apps/{video_id}/movie_max.mp4"
            v["url_webm"] = f"https://cdn.akamai.steamstatic.com/steam/apps/{video_id}/movie480_vp9.webm"
            total_videos += 1
    actualizados += 1

print(f"Juegos actualizados: {actualizados}")
print(f"Videos con fallbacks anadidos: {total_videos}")

print("\nGuardando JSON...")
with open(ARCHIVO, "w", encoding="utf-8") as f:
    json.dump(datos, f, ensure_ascii=False, indent=2)

print("Listo!")
print("\nAhora ejecuta indice_web.py opcion 1 para regenerar el HTML.")
input("\nPulsa Enter para cerrar...")
