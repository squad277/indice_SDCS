"""
SDCS INDEX MANAGER - App de escritorio
by Claude para Squad_277
"""

import os
import sys
import json
import threading
import customtkinter as ctk
from tkinter import messagebox
from PIL import Image
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("dark-blue")

# Colores SDCS (mismos que la web)
COLOR_PRIMARIO = "#00d4aa"
COLOR_PRIMARIO_HOVER = "#00f0c0"
COLOR_FONDO = "#0d1117"
COLOR_CARD = "#161b22"
COLOR_BORDE = "#1a1f2e"
COLOR_TEXTO = "#c9d1d9"
COLOR_TEXTO_SECUNDARIO = "#9ca3af"
COLOR_TEXTO_MUTED = "#6b7280"
COLOR_ERROR = "#ef4444"

ARCHIVO_DATOS = "indice_datos_grupo.json"
ARCHIVO_LOGO = "logo_sdcs.jpg"


def cargar_estadisticas():
    if not os.path.exists(ARCHIVO_DATOS):
        return None
    try:
        with open(ARCHIVO_DATOS, "r", encoding="utf-8") as f:
            datos = json.load(f)
        juegos = datos.get("juegos", [])
        total = len(juegos)
        con_local = sum(1 for j in juegos if j.get("imagen_local"))
        con_steam = sum(1 for j in juegos if not j.get("imagen_local") and j.get("app_id"))
        cobertura = ((con_local + con_steam) * 100 // total) if total else 0
        mtime = os.path.getmtime(ARCHIVO_DATOS)
        ultima_sync = datetime.fromtimestamp(mtime).strftime("%d/%m %H:%M")
        return {"total": total, "ultima_sync": ultima_sync, "cobertura": cobertura}
    except:
        return None


class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("SDCS Index Manager")
        self.geometry("560x860")
        self.resizable(False, False)
        self.configure(fg_color=COLOR_FONDO)
        if os.path.exists(ARCHIVO_LOGO):
            try:
                self.iconbitmap(default=ARCHIVO_LOGO)
            except:
                pass
        self._construir_ui()
        self._actualizar_stats()

    def _construir_ui(self):
        # === HEADER ===
        header = ctk.CTkFrame(self, fg_color=COLOR_BORDE, corner_radius=0, height=130)
        header.pack(fill="x")
        header.pack_propagate(False)

        linea_verde = ctk.CTkFrame(header, fg_color=COLOR_PRIMARIO, height=3, corner_radius=0)
        linea_verde.pack(side="bottom", fill="x")

        header_inner = ctk.CTkFrame(header, fg_color="transparent")
        header_inner.pack(fill="both", expand=True, padx=24, pady=20)

        # Logo
        logo_container = ctk.CTkFrame(header_inner, fg_color="transparent", width=72, height=72)
        logo_container.pack(side="left", padx=(0, 16))
        logo_container.pack_propagate(False)

        if os.path.exists(ARCHIVO_LOGO):
            try:
                img = Image.open(ARCHIVO_LOGO)
                img = img.resize((72, 72), Image.LANCZOS)
                logo_img = ctk.CTkImage(light_image=img, dark_image=img, size=(72, 72))
                logo_label = ctk.CTkLabel(logo_container, image=logo_img, text="",
                                          fg_color="transparent", corner_radius=10)
                logo_label.pack(fill="both", expand=True)
                logo_label.image = logo_img
            except Exception as e:
                self._logo_fallback(logo_container)
        else:
            self._logo_fallback(logo_container)

        # Titulos
        titles = ctk.CTkFrame(header_inner, fg_color="transparent")
        titles.pack(side="left", fill="both", expand=True)
        ctk.CTkFrame(titles, fg_color="transparent", height=4).pack()
        ctk.CTkLabel(titles, text="SDCS · Grupo Steam Deck",
                    text_color="white", font=ctk.CTkFont(size=20, weight="bold"),
                    anchor="w").pack(anchor="w")
        sub_frame = ctk.CTkFrame(titles, fg_color="transparent")
        sub_frame.pack(anchor="w", pady=(2, 0))
        ctk.CTkLabel(sub_frame, text="◆", text_color=COLOR_PRIMARIO,
                    font=ctk.CTkFont(size=10)).pack(side="left", padx=(0, 6))
        ctk.CTkLabel(sub_frame, text="ÍNDICE WEB · SQUAD_277",
                    text_color=COLOR_TEXTO_SECUNDARIO,
                    font=ctk.CTkFont(size=11, weight="bold"),
                    anchor="w").pack(side="left")

        # === STATS BAR ===
        stats_bar = ctk.CTkFrame(self, fg_color="#0a0d12", corner_radius=0, height=92)
        stats_bar.pack(fill="x")
        stats_bar.pack_propagate(False)

        stats_inner = ctk.CTkFrame(stats_bar, fg_color="transparent")
        stats_inner.pack(fill="both", expand=True, padx=24, pady=14)

        self.stat_total = self._crear_stat_card(stats_inner, "🎮", "JUEGOS", "—")
        self.stat_total.pack(side="left", padx=(0, 8), fill="both", expand=True)

        self.stat_sync = self._crear_stat_card(stats_inner, "🔄", "ÚLTIMA SYNC", "—", small=True)
        self.stat_sync.pack(side="left", padx=(0, 8), fill="both", expand=True)

        self.stat_cobertura = self._crear_stat_card(stats_inner, "✅", "COBERTURA", "—%")
        self.stat_cobertura.pack(side="left", fill="both", expand=True)

        # === BODY ===
        body = ctk.CTkFrame(self, fg_color=COLOR_FONDO, corner_radius=0)
        body.pack(fill="both", expand=True, padx=24, pady=22)

        # Acciones
        titulo_frame_acc = ctk.CTkFrame(body, fg_color="transparent")
        titulo_frame_acc.pack(fill="x", pady=(0, 12))
        ctk.CTkFrame(titulo_frame_acc, fg_color=COLOR_PRIMARIO, width=3, height=14).pack(side="left", padx=(0, 8))
        ctk.CTkLabel(titulo_frame_acc, text="ACCIONES PRINCIPALES",
                    text_color=COLOR_TEXTO,
                    font=ctk.CTkFont(size=11, weight="bold"),
                    anchor="w").pack(side="left")

        self._crear_btn_principal(body, "⚡", "Actualización rápida",
                                  "Solo busca juegos nuevos · ~30 seg",
                                  "#1a3a5c",
                                  lambda: self._ejecutar_modo("1"))
        self._crear_btn_principal(body, "🧹", "Limpieza completa",
                                  "Verifica todos los juegos · ~5 min",
                                  "#3d2c5c",
                                  lambda: self._ejecutar_modo("2"))
        self._crear_btn_principal(body, "🔄", "Reprocesar datos",
                                  "Mejora nombres y app_ids · ~10 min",
                                  "#5c2d1a",
                                  lambda: self._ejecutar_modo("3"))

        # Herramientas
        titulo_frame_tools = ctk.CTkFrame(body, fg_color="transparent")
        titulo_frame_tools.pack(fill="x", pady=(20, 12))
        ctk.CTkFrame(titulo_frame_tools, fg_color=COLOR_PRIMARIO, width=3, height=14).pack(side="left", padx=(0, 8))
        ctk.CTkLabel(titulo_frame_tools, text="HERRAMIENTAS",
                    text_color=COLOR_TEXTO,
                    font=ctk.CTkFont(size=11, weight="bold"),
                    anchor="w").pack(side="left")

        tools_frame = ctk.CTkFrame(body, fg_color="transparent")
        tools_frame.pack(fill="x")

        self._crear_btn_pequeno(tools_frame, "📊", "Estadísticas", self._abrir_estadisticas, 0)
        self._crear_btn_pequeno(tools_frame, "🔍", "Duplicados", self._abrir_duplicados, 1)
        self._crear_btn_pequeno(tools_frame, "💾", "Backup", self._abrir_backup, 2)
        self._crear_btn_pequeno(tools_frame, "🌐", "Abrir web", self._abrir_web, 3)

        tools_frame.grid_columnconfigure(0, weight=1)
        tools_frame.grid_columnconfigure(1, weight=1)
        tools_frame.grid_columnconfigure(2, weight=1)
        tools_frame.grid_columnconfigure(3, weight=1)

        # Footer
        footer = ctk.CTkFrame(self, fg_color="#080a0d", corner_radius=0, height=36)
        footer.pack(fill="x", side="bottom")
        footer.pack_propagate(False)
        linea_footer = ctk.CTkFrame(footer, fg_color="#162028", height=1, corner_radius=0)
        linea_footer.pack(side="top", fill="x")
        ctk.CTkLabel(footer, text="◆ SDCS v3.0",
                    text_color=COLOR_PRIMARIO, font=ctk.CTkFont(size=10, weight="bold")).pack(side="left", padx=24)
        ctk.CTkLabel(footer, text="squad277.github.io/indice_SDCS",
                    text_color=COLOR_TEXTO_MUTED, font=ctk.CTkFont(size=10)).pack(side="right", padx=24)

    def _logo_fallback(self, parent):
        frame = ctk.CTkFrame(parent, fg_color=COLOR_PRIMARIO, corner_radius=10)
        frame.pack(fill="both", expand=True)
        ctk.CTkLabel(frame, text="SQ", fg_color="transparent",
                    text_color=COLOR_FONDO, font=ctk.CTkFont(size=24, weight="bold")).pack(fill="both", expand=True)

    def _crear_stat_card(self, parent, icono, label, value, small=False):
        card = ctk.CTkFrame(parent, fg_color="#161b22", corner_radius=8,
                            border_width=1, border_color="#1f242c")
        inner = ctk.CTkFrame(card, fg_color="transparent")
        inner.pack(fill="both", expand=True, padx=12, pady=10)

        top_row = ctk.CTkFrame(inner, fg_color="transparent")
        top_row.pack(fill="x", anchor="w")
        ctk.CTkLabel(top_row, text=icono, font=ctk.CTkFont(size=12),
                    text_color=COLOR_PRIMARIO).pack(side="left", padx=(0, 5))
        ctk.CTkLabel(top_row, text=label,
                    text_color=COLOR_TEXTO_MUTED,
                    font=ctk.CTkFont(size=9, weight="bold"),
                    anchor="w").pack(side="left")

        size = 12 if small else 17
        valor_label = ctk.CTkLabel(inner, text=value,
                                   text_color=COLOR_PRIMARIO,
                                   font=ctk.CTkFont(size=size, weight="bold"),
                                   anchor="w")
        valor_label.pack(anchor="w", pady=(4, 0))
        card.valor_label = valor_label
        return card

    def _crear_btn_principal(self, parent, icono, titulo, subtitulo, color_icono, comando):
        btn = ctk.CTkFrame(parent, fg_color=COLOR_CARD, corner_radius=10,
                          border_width=1, border_color="#1f242c", height=72)
        btn.pack(fill="x", pady=(0, 9))
        btn.pack_propagate(False)

        icon_frame = ctk.CTkFrame(btn, fg_color=color_icono, corner_radius=8, width=46, height=46)
        icon_frame.pack(side="left", padx=14, pady=13)
        icon_frame.pack_propagate(False)
        ctk.CTkLabel(icon_frame, text=icono, font=ctk.CTkFont(size=20)).pack(fill="both", expand=True)

        texto_frame = ctk.CTkFrame(btn, fg_color="transparent")
        texto_frame.pack(side="left", fill="both", expand=True, pady=14)
        ctk.CTkLabel(texto_frame, text=titulo,
                    text_color="white", font=ctk.CTkFont(size=14, weight="bold"),
                    anchor="w").pack(anchor="w")
        ctk.CTkLabel(texto_frame, text=subtitulo,
                    text_color=COLOR_TEXTO_SECUNDARIO, font=ctk.CTkFont(size=11),
                    anchor="w").pack(anchor="w", pady=(2, 0))

        flecha_label = ctk.CTkLabel(btn, text="›", text_color=COLOR_PRIMARIO,
                    font=ctk.CTkFont(size=22, weight="bold"))
        flecha_label.pack(side="right", padx=18)

        def on_enter(e):
            btn.configure(border_color=COLOR_PRIMARIO, fg_color="#1a2028")
            flecha_label.configure(text_color=COLOR_PRIMARIO_HOVER)
        def on_leave(e):
            btn.configure(border_color="#1f242c", fg_color=COLOR_CARD)
            flecha_label.configure(text_color=COLOR_PRIMARIO)
        def on_click(e):
            comando()

        for widget in [btn, icon_frame, texto_frame, flecha_label] + list(texto_frame.winfo_children()) + list(icon_frame.winfo_children()):
            widget.bind("<Enter>", on_enter)
            widget.bind("<Leave>", on_leave)
            widget.bind("<Button-1>", on_click)
            widget.configure(cursor="hand2")

    def _crear_btn_pequeno(self, parent, icono, texto, comando, columna):
        btn_frame = ctk.CTkFrame(parent, fg_color="#161b22", corner_radius=8,
                                  border_width=1, border_color="#1f242c", height=58)
        btn_frame.grid(row=0, column=columna, padx=3, sticky="ew")
        btn_frame.grid_propagate(False)

        ctk.CTkLabel(btn_frame, text=icono, font=ctk.CTkFont(size=18)).pack(pady=(8, 0))
        ctk.CTkLabel(btn_frame, text=texto,
                    text_color=COLOR_TEXTO_SECUNDARIO,
                    font=ctk.CTkFont(size=10, weight="bold")).pack(pady=(2, 0))

        def on_enter(e):
            btn_frame.configure(border_color=COLOR_PRIMARIO, fg_color="#1a2028")
        def on_leave(e):
            btn_frame.configure(border_color="#1f242c", fg_color="#161b22")
        def on_click(e):
            comando()

        for widget in [btn_frame] + list(btn_frame.winfo_children()):
            widget.bind("<Enter>", on_enter)
            widget.bind("<Leave>", on_leave)
            widget.bind("<Button-1>", on_click)
            widget.configure(cursor="hand2")

    def _actualizar_stats(self):
        stats = cargar_estadisticas()
        if stats:
            self.stat_total.valor_label.configure(text=f"{stats['total']:,}")
            self.stat_sync.valor_label.configure(text=stats['ultima_sync'])
            self.stat_cobertura.valor_label.configure(text=f"{stats['cobertura']}%")
        self.after(30000, self._actualizar_stats)

    def _ejecutar_modo(self, modo):
        VentanaEjecucion(self, modo)

    def _abrir_estadisticas(self):
        os.system("start cmd /k python estadisticas.py")

    def _abrir_duplicados(self):
        os.system("start cmd /k python duplicados.py")

    def _abrir_backup(self):
        respuesta = messagebox.askyesno("Backup completo",
            "Esto creará un ZIP con todo el proyecto y lo subirá a GitHub.\n¿Continuar?")
        if respuesta:
            os.system("start cmd /k python backup_completo.py")

    def _abrir_web(self):
        import webbrowser
        webbrowser.open("https://squad277.github.io/indice_SDCS/")


class VentanaEjecucion(ctk.CTkToplevel):
    """Ventana modal con LOG simple (sin barras visuales)"""

    NOMBRES_MODOS = {
        "1": "Actualización rápida",
        "2": "Limpieza completa",
        "3": "Reprocesar datos"
    }

    def __init__(self, parent, modo):
        super().__init__(parent)
        self.modo = modo

        self.title(f"Ejecutando: {self.NOMBRES_MODOS[modo]}")
        self.geometry("520x500")
        self.resizable(False, False)
        self.configure(fg_color=COLOR_FONDO)

        self.transient(parent)
        self.grab_set()

        self._construir_ui()
        self._iniciar_proceso()

    def _construir_ui(self):
        # Header
        header = ctk.CTkFrame(self, fg_color=COLOR_BORDE, corner_radius=0, height=80)
        header.pack(fill="x")
        header.pack_propagate(False)

        linea_verde = ctk.CTkFrame(header, fg_color=COLOR_PRIMARIO, height=2, corner_radius=0)
        linea_verde.pack(side="bottom", fill="x")

        ctk.CTkLabel(header, text=self.NOMBRES_MODOS[self.modo],
                    text_color="white", font=ctk.CTkFont(size=16, weight="bold")).pack(pady=(15, 0))
        self.estado_label = ctk.CTkLabel(header, text="Iniciando...",
                                         text_color=COLOR_TEXTO_SECUNDARIO,
                                         font=ctk.CTkFont(size=11))
        self.estado_label.pack()

        # Body
        body = ctk.CTkFrame(self, fg_color=COLOR_FONDO, corner_radius=0)
        body.pack(fill="both", expand=True, padx=24, pady=18)

        ctk.CTkLabel(body, text="LOG DE EJECUCIÓN",
                    text_color=COLOR_TEXTO_MUTED,
                    font=ctk.CTkFont(size=10, weight="bold"),
                    anchor="w").pack(anchor="w", pady=(0, 6))

        self.log_text = ctk.CTkTextbox(body, fg_color="#0a0d12",
                                       text_color=COLOR_TEXTO,
                                       font=ctk.CTkFont(family="Consolas", size=11),
                                       border_width=1, border_color="#1f242c",
                                       height=300)
        self.log_text.pack(fill="both", expand=True)
        self.log_text.configure(state="disabled")

        botones = ctk.CTkFrame(body, fg_color="transparent")
        botones.pack(fill="x", pady=(14, 0))

        self.btn_cerrar = ctk.CTkButton(botones, text="Cerrar",
                                        fg_color=COLOR_PRIMARIO, hover_color=COLOR_PRIMARIO_HOVER,
                                        text_color=COLOR_FONDO,
                                        font=ctk.CTkFont(size=12, weight="bold"),
                                        corner_radius=6, height=36,
                                        state="disabled",
                                        command=self.destroy)
        self.btn_cerrar.pack(fill="x")

    def _log(self, mensaje):
        def _add():
            self.log_text.configure(state="normal")
            self.log_text.insert("end", mensaje + "\n")
            self.log_text.see("end")
            self.log_text.configure(state="disabled")
        self.after(0, _add)

    def _set_estado(self, texto):
        self.after(0, lambda: self.estado_label.configure(text=texto))

    def _iniciar_proceso(self):
        thread = threading.Thread(target=self._ejecutar, daemon=True)
        thread.start()

    def _ejecutar(self):
        try:
            self._set_estado("Ejecutando script...")
            self._log(f"=== Iniciando {self.NOMBRES_MODOS[self.modo]} ===\n")

            import subprocess

            env = os.environ.copy()
            env["PYTHONIOENCODING"] = "utf-8"
            env["PYTHONUNBUFFERED"] = "1"

            proc = subprocess.Popen(
                [sys.executable, "-u", "indice_web.py"],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                bufsize=1,
                env=env,
                creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
            )

            try:
                proc.stdin.write(f"{self.modo}\n\n")
                proc.stdin.flush()
                proc.stdin.close()
            except Exception as e:
                self._log(f"Error enviando opcion: {e}")

            for linea in proc.stdout:
                linea = linea.rstrip()
                if linea:
                    self._log(linea)
                    if "Conectado a Telegram" in linea:
                        self._set_estado("Conectado · Procesando...")
                    elif "Generando HTML" in linea:
                        self._set_estado("Generando HTML...")
                    elif "Subiendo HTML" in linea:
                        self._set_estado("Subiendo a GitHub...")
                    elif "Indice listo" in linea or "[OK]" in linea:
                        self._set_estado("¡Completado!")

            proc.wait()

            self._log(f"\n=== Proceso terminado (codigo {proc.returncode}) ===")
            self._set_estado("Completado · Pulsa Cerrar")
            self.after(0, lambda: self.btn_cerrar.configure(state="normal"))

        except Exception as e:
            self._log(f"\nERROR: {e}")
            self._set_estado("Error en la ejecucion")
            self.after(0, lambda: self.btn_cerrar.configure(state="normal"))


if __name__ == "__main__":
    app = App()
    app.mainloop()
