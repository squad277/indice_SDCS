"""
Re-descarga la info Steam para volver a obtener los videos
con la URL correcta (movie480.mp4 reconstruida desde el ID).

Solo actualiza los videos, mantiene el resto intacto.
"""
import json
import time
import requests

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
}

ARCHIVO = "indice_datos_grupo.json"

print("=" * 60)
print("ACTUALIZAR VIDEOS EN STEAM_INFO")
print("=" * 60)

with open(ARCHIVO, "r", encoding="utf-8") as f:
    datos = json.load(f)

juegos_con_steam = [j for j in datos["juegos"] 
                    if j.get("steam_info") and not j.get("steam_info", {}).get("error")]

print(f"\nJuegos con steam_info: {len(juegos_con_steam)}")
print(f"Recargando solo el campo 'movies' para reconstruir URLs MP4...")
print(f"Tiempo estimado: ~{len(juegos_con_steam) * 1.5 / 60:.0f} minutos\n")

actualizados = 0
con_videos = 0
sin_videos = 0
fallidos = 0

for i, juego in enumerate(juegos_con_steam):
    if i % 50 == 0:
        print(f"Progreso: {i}/{len(juegos_con_steam)} - Con videos: {con_videos}")
    
    app_id = juego["app_id"]
    
    try:
        url = f"https://store.steampowered.com/api/appdetails?appids={app_id}&l=spanish&cc=es&filters=movies"
        r = requests.get(url, headers=HEADERS, timeout=10)
        if r.status_code != 200:
            fallidos += 1
            time.sleep(1.5)
            continue
        
        data = r.json()
        d = data.get(str(app_id), {}).get("data", {})
        if not d:
            fallidos += 1
            time.sleep(1.5)
            continue
        
        movies = d.get("movies", [])
        videos_nuevos = []
        
        for v in movies[:2]:
            video_id = v.get("id")
            if video_id:
                videos_nuevos.append({
                    "url": f"https://cdn.akamai.steamstatic.com/steam/apps/{video_id}/movie480.mp4",
                    "url_max": f"https://cdn.akamai.steamstatic.com/steam/apps/{video_id}/movie_max.mp4",
                    "url_webm": f"https://cdn.akamai.steamstatic.com/steam/apps/{video_id}/movie480_vp9.webm",
                    "thumb": v.get("thumbnail", "")
                })
        
        # Actualizar solo el campo videos
        juego["steam_info"]["videos"] = videos_nuevos
        
        if videos_nuevos:
            con_videos += 1
        else:
            sin_videos += 1
        actualizados += 1
        
        # Pausa entre peticiones
        time.sleep(1.5)
        
        # Guardar parcial cada 100
        if (i + 1) % 100 == 0:
            with open(ARCHIVO, "w", encoding="utf-8") as f:
                json.dump(datos, f, ensure_ascii=False, indent=2)
    
    except Exception as e:
        fallidos += 1
        time.sleep(1.5)

# Guardar al final
with open(ARCHIVO, "w", encoding="utf-8") as f:
    json.dump(datos, f, ensure_ascii=False, indent=2)

print("\n" + "=" * 60)
print("RESUMEN")
print("=" * 60)
print(f"  Actualizados: {actualizados}")
print(f"  CON videos: {con_videos}")
print(f"  Sin videos (no tienen): {sin_videos}")
print(f"  Fallidos: {fallidos}")

print("\nAhora ejecuta indice_web.py opcion 1 para regenerar el HTML.")
input("\nPulsa Enter para cerrar...")
